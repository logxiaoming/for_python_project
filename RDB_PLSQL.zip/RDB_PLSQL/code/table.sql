--������
1,
create table CUSTOMER
(
  cno    VARCHAR2(50) primary key,
  cname  VARCHAR2(50) not null,
  cphone VARCHAR2(50),
  cadd   VARCHAR2(50)
)
2,
create table ODER
(
  dno     VARCHAR2(50) not null,
  cno     VARCHAR2(50) not null,
  paytool VARCHAR2(50),
  company VARCHAR2(50),
  add2    VARCHAR2(50)
)
alter table oder
 add primary key(dno)
 alter table oder
 add gno varchar2(50);
 alter table oder add odertime date;
 alter table oder add constraint fk_01 foreign key(cno) references  customer(cno);
 alter table oder add constraint fk_02 foreign key(gno) references goods(gno);
3,
create table GOODS
(
  gno     VARCHAR2(50) not null,
  gname   VARCHAR2(50) not null,
  price   VARCHAR2(50),
  gweight NUMBER(4,2),
  goodlx  VARCHAR2(50) )
  alter table goods 
  modify price number(8,2);
  alter table goods
  add  gsum number(4);
  
alter table goods add primary key(gno)
4,
create table room
(
  rno     varchar2(50) primary key,
  rsize   varchar2(50),
  maxload varchar2(50),
  pno     varchar2(50)
)
 alter table room add constraint fk_03 foreign key(pno) references person(pno);
5,
create table truck
(
  license    varchar2(50) primary key,
  type   varchar2(50),
  truckstatus varchar2(50),
  loadweight   number(8)
)
6,
create table person
(
  pno    varchar2(50) primary key,
  pname   varchar2(50),
  psex varchar2(50),
  padd     varchar2(50),
  pphone  varchar2(50),
  ptitle varchar2(50),
  pbirth date,
  pstartwork date,
  pcredicard varchar2(50),
  psalary number(10,2),
  pstatus varchar2(50)
)
7,
create table saveoder
(
  dno     varchar2(50) ,
  pno  varchar2(50),
  ordersure varchar2(50),
  orderfinish    varchar2(50),
  span     varchar2(50),
  savetime     varchar2(50),
  primary key(dno,pno),
  foreign key(pno) 
  references person(pno)
)
alter table saveoder 
  modify savetime date;
 alter table saveoder add constraint fk_04 foreign key(pno) references person(pno);
 alter table saveoder add constraint fk_05 foreign key(dno) references oder(dno);
8,
create table schedule
(
  dno varchar2(50) not null,
  pno varchar2(50) references person(pno),
  license varchar2(50),
  gno varchar2(50),
  startime date ,
  endtime  varchar2(50),
   add1    varchar2(50),
   add2    varchar2(50),
  primary key(dno,pno)
)
alter table schedule modify endtime date;
alter table schedule drop column add2;
alter table schedule add constraint fk_06 foreign key(pno) references person(pno);
alter table schedule add constraint fk_07 foreign key(dno) references oder(dno);
alter table schedule add constraint fk_08 foreign key(license) references truck(license);
alter table schedule add constraint fk_09 foreign key(gno) references goods(gno);
9,
create table distribute
(
  dno varchar2(50) references oder(dno),
  pno varchar2(50) references person(pno),
  gno varchar2(50) references goods(gno),
  distritime date ,
  add2    varchar2(50),
  primary key(dno,pno,gno)
)
alter table distribute
add cno varchar2(50);
alter table distribute add constraint fk_10 foreign key(gno) references goods(gno);
alter table distribute add constraint fk_11 foreign key(dno) references oder(dno);
alter table distribute add constraint fk_12 foreign key(pno) references person(pno);

10,
create table logist
(
  cno varchar2(50) references customer(cno),
  gno varchar2(50) references goods(gno),
  orderstatus varchar2(50),
  processtatus varchar2(50),
  primary key(cno,gno)
)
alter table logist add dno varchar2(50);
alter table logist add primary key(dno);

11,
create table sign(
dno varchar2(50) primary key,
cno varchar2(50) not null,
signstatus varchar2(50),
signtime date,
foreign key(dno) references oder(dno)
);

--��ͼ
1,
create or replace view logistatus as
select oder.company,oder.dno,customer.cname,goods.gname,gsum,price,schedule.add1,
oder.add2,schedule.startime,to_date(schedule.endtime,'yyyy/mm/dd') endtime,person.pname,person.pphone
from customer,oder,goods,schedule��distribute,person
where  oder.dno=schedule.dno and oder.cno=customer.cno 
and oder.gno=goods.gno and oder.dno=distribute.dno and distribute.pno=person.pno
with check option;

2,
create or replace view fare as 
select gno,gname,gsum,gweight
from goods ; 

3,
create or replace view person_schedule as 
select schedule.dno,distribute.pno,schedule.gno,schedule.startime,
schedule.endtime,schedule.add1,distribute.add2 ,distribute.cno 
from schedule FULL OUTER JOIN distribute on (schedule.dno=distribute.dno)
with check option;


--�����洢����
1,
create or replace procedure query_logistatus(x in logistatus.dno%type) 
is
a logistatus%rowtype;
begin
  select * into a
  from logistatus
  where dno=x;
  
  dbms_output.put_line(a.company||', '||a.dno||', '||a.cname||', '||a.cname||', '||
  a.gname||', '||a.gsum||', '||a.price||', '||a.add1||', '||a.add2||', '||a.startime
  ||', '||a.endtime||', '||a.pname||', '||a.pphone);
end query_logistatus;

2,
create or replace procedure fareDetail(x in oder.dno%type)
is
a fare%rowtype;
b goods.price%type;
c goods.gno%type;
begin
  select oder.gno into c from oder where x=dno;
  select * into a from fare where fare.gno=c;
  b:=a.gsum*a.gweight*10;
   dbms_output.put_line(a.gno||', '||a.gname||', '||b||'Ԫ�˷�');
end fareDetail;


3,
create or replace procedure send_oder(sdno in oder.dno%type,scno in oder.cno%type,
spaytool in oder.paytool%type,scompany in oder.company%type,sadd2 in oder.add2%type,
sgno in oder.gno%type,sodertime in oder.odertime%type) 
is
begin
  insert into oder(dno,cno,paytool,company,add2,gno,odertime)
  values(sdno,scno,spaytool,scompany,sadd2,sgno,sodertime);
  
   update_distribute(sdno);
   
   update_logist(sdno);
   
    update_sign(sdno);
    
    update_saveoder(sdno);
   
  dbms_output.put_line('�ɹ����յ��µĶ�����');
end send_oder;

4,
create or replace procedure update_distribute(ndno in oder.dno%type) 
is
npno person.pno%type;
ngno oder.gno%type;
ndistritime schedule.startime%type;
nadd2 oder.add2%type;
ncno oder.cno%type;
begin
  select gno,add2,cno into ngno,nadd2,ncno from oder where dno=ndno;
  select pno,startime into npno,ndistritime from schedule where schedule.dno=ndno;
  insert into distribute
  values(ndno,npno,ngno,ndistritime,nadd2,ncno);
  dbms_output.put_line('���³ɹ���');
end update_distribute;

5,
create or replace procedure update_logist(ndno in oder.dno%type)
is
ngno oder.gno%type;
ncno oder.cno%type;
a logist.orderstatus%type:='���µ�';
b logist.processtatus%type:='�ѷ���';
begin
  select gno,cno into ngno,ncno from oder where dno=ndno;
  insert into logist
  values(ncno,ngno,a,b,ndno);
   dbms_output.put_line('���³ɹ���');
end update_logist;

6,
create or replace procedure update_sign(ndno in oder.dno%type) 
is
ncno oder.cno%type;
a varchar2(20);
ntime  date;
begin
  a:='��ǩ��';
  select cno into ncno from oder where dno=ndno;
  select endtime into ntime from schedule where dno=ndno;
  insert into sign
  values(ndno,ncno,a,ntime);
  dbms_output.put_line('���³ɹ���');
end update_sign;

7,
create or replace procedure update_saveoder(ndno in oder.dno%type) 
is
ntime date;
begin
  select signtime into ntime from sign where ndno=dno;
  insert into saveoder
  values(ndno,'p0010','��ȷ��','�����',3,ntime);
end update_saveoder;

8,
create or replace procedure delete_oder(ndno in oder.dno%type) 
is
begin
  delete from oder where ndno=oder.dno;
   dbms_output.put_line('�ɹ�ȡ��������');
end delete_oder;

9,
create or replace procedure query_person_schedule(x in person.pno%type) 
is
a person_schedule%rowtype;
cursor c1 is 
select * from person_schedule where pno=x;
begin
  open c1;
  loop
    fetch c1 into a;
    exit when c1%notfound;
    dbms_output.put_line(a.dno||', '||a.pno||', '||a.gno||', '||a.startime
    ||', '||a.endtime||', '||a.add1||', '||a.add2||', '||a.cno );
 end loop;
 close c1;
end query_person_schedule;

10,
create or replace procedure query_person(x in person.pno%type) 
is
a person%rowtype;
cursor c2 is 
select * from person where pno=x;
begin
  open c2;
  loop
    fetch c2 into a;
    exit when c2%notfound;
    dbms_output.put_line(a.pno||', '||a.pname||', '||a.psex||', '||a.padd
    ||', '||a.pphone||', '||a.ptitle||', '||a.pbirth||', '||a.pstartwork||', '||
    a.pcredicard||', '||a.psalary||', '||a.pstatus );
 end loop;
  close c2;
end query_person;


--����������
1,
create or replace trigger update_schedule
  after insert
  on oder 
  for each row
declare
  -- local variables here
  spno person.pno%type:='p0002';
  slicense truck.license%type:='t0002';
  --ntime date:=to_date(:new.odertime,'yyyy/mm/dd');
  ntime date:= :new.odertime;
  nadd1 customer.cadd%type;
begin
  --select oder.odertime into ntime from oder where oder.dno=:new.dno;
  select cadd into nadd1 from customer where customer.cno=:new.cno;
  
  insert into schedule
  values(:new.dno,spno,slicense,:new.gno,ntime+1,ntime+4,nadd1);
   --dbms_output.put_line(:new.dno||' '||to_char(ntime+2));
end update_schedule;

2,
create or replace trigger delete_schedule
  after delete
  on oder
  for each row
declare
  -- local variables here
begin
  delete from schedule where :old.dno=schedule.dno ;
end delete_schedule;

3,
create or replace trigger delete_distribute
  after delete
  on oder 
  for each row
declare
  -- local variables here
begin
  delete from distribute where :old.dno=distribute.dno;
end delete_distribute;

4,
create or replace trigger delete_logist
  after delete
  on oder 
  for each row
declare
  -- local variables here
begin
  delete from logist where :old.dno=logist.dno;
end delete_logist;

5,
create or replace trigger delete_sign
  after delete
  on saveoder 
  for each row
declare
  -- local variables here
begin
  delete from sign where :old.dno=sign.dno;
end delete_saveoder;

6,
create or replace trigger delete_oder
  after delete
  on saveoder 
  for each row
declare
  -- local variables here
begin
  delete from saveoder where :old.dno=saveoder.dno;
end delete_oder;



--�����û�
1,worker
create user WORKER
  default tablespace USERS
  temporary tablespace TEMP
  profile DEFAULT
  password expire;
-- Grant/Revoke object privileges 
grant select on PERSON to WORKER;
grant select on PERSON_SCHEDULE to WORKER;
-- Grant/Revoke role privileges 
grant connect to WORKER

2,client
create user CLIENT
  default tablespace USERS
  temporary tablespace TEMP
  profile DEFAULT
  password expire;
-- Grant/Revoke object privileges 
grant select on FARE to CLIENT;
grant select on LOGISTATUS to CLIENT;
-- Grant/Revoke role privileges 
grant connect to CLIENT;

3,user1(manager)
create user USER1
  default tablespace USERS
  temporary tablespace TEMP
  profile DEFAULT
  password expire;
-- Grant/Revoke role privileges 
grant dba to USER1;
grant rperson to USER1 with admin option;
-- Grant/Revoke system privileges 
grant unlimited tablespace to USER1;



--��Ȩ
1,����ͨԱ����ѯ������Ϣ��Ȩ��
create role rperson;
grant select on person
to rperson ;
grant select on person_schedule to worker;
grant select on person to worker;
grant execute on query_person to worker;
grant execute on query_person_schedule to worker;

2,���˿������ѯ���������Ͷ�����Ȩ��
grant select on fare to client;
grant select on logistatus to client;
grant insert on oder to client;
grant execute on faredetail to client;
grant execute on query_logistatus to client;
grant execute on send_oder to client;

3,����ԱĬ������Ȩ��
grant dba to user1;



--����
select * from logist where cno='c0001';

select customer.cname ����,gname ��Ʒ,price �۸�,gsum ����,processtatus ����״̬,
distribute.add2 ���͵�ַ,distribute.distritime ����ʱ��
from logist,goods,customer,distribute
where customer.cno='c0001' and logist.gno=goods.gno and logist.cno=customer.cno 
and distribute.gno=goods.gno;

select company ��˾,dno ������,cname �ջ���,gname ����,gsum ����,price �۸�,
add1 ������,add2 �ջ���,startime ����ʱ��,endtime ����ʱ��,pname ����Ա,pphone ��ϵ�绰
from logistatus where dno='d0001';

declare 
x oder.dno%type:='d0001';
begin
  query_logistatus(x);
end;

declare 
x goods.gno%type:='g0019';
begin
 faredetail(x);
end;

declare
sdno oder.dno%type:='d0070';
scno oder.cno%type:='c0002';
spaytool oder.paytool%type:='֧����';
scompany oder.company%type:='��ͨ';
sadd2 oder.add2%type:='����ʡ������������13��';
sgno oder.gno%type:='g0019';
sodertime oder.odertime%type:=to_date('2023/6/1','yyyy/mm/dd');
begin
  send_oder(sdno,scno,spaytool,scompany,sadd2,sgno,sodertime);
end;
commit;

select * from oder where dno='d0016';
delete from oder where dno='d0017';commit;
select * from schedule where dno='d0017';

declare 
x oder.dno%type:='d0017';
begin
  update_distribute(x);
end;

declare 
x oder.dno%type:='d0017';
begin
  update_logist(x);
end;

declare 
x oder.dno%type:='d0017';
begin
  update_sign(x);
end;

declare 
x oder.dno%type:='d0017';
begin
  update_saveoder(x);
end;

declare
sdno oder.dno%type:='d0019';
scno oder.cno%type:='c0003';
spaytool oder.paytool%type:='֧����';
scompany oder.company%type:='��ͨ';
sadd2 oder.add2%type:='����ʡ������������17��';
sgno oder.gno%type:='g0018';
sodertime oder.odertime%type:=to_date('2023/6/10','yyyy/mm/dd');
begin
  send_oder(sdno,scno,spaytool,scompany,sadd2,sgno,sodertime);
end;
commit;

select * from logistatus where dno='d0010';
select * from logistatus where dno='d0019';
select dno �������,pno �浵��,orderfinish �������״̬,span ��ʱ,savetime �浵ʱ��
 from saveoder where dno='d0044';
select * from logist where dno='d0044';
select * from schedule where dno='d0044';
select * from oder where dno='d0044';
select dno �������,cno �ͻ�,signstatus ǩ��״̬, signtime ǩ��ʱ��
 from sign where dno='d0044';

declare 
x oder.dno%type:='d0015';
begin
  faredetail(x);
end;

declare 
x oder.dno%type:='d0044';
begin
  delete_oder(x);
end;
commit;

select * from person_schedule;

select * from person_schedule where pno='p0014';

declare 
x person.pno%type:='p0015';
begin
  query_person_schedule(x);
end;

declare 
x person.pno%type:='p0015';
begin
  query_person(x);
end;

grant select on person_schedule to worker;
grant select on person to worker;

grant select on fare to client;
grant select on logistatus to client;





