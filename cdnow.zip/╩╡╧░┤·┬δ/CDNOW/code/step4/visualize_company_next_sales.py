
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
#设定绘图风格
plt.style.use('ggplot')
sns.set(style='whitegrid',font='./myfont.TTF')


data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\predict_company_next_10moth_sales.xlsx',
                     'sheet2')


plt.figure(figsize=(16, 12))
plt.rcParams['font.family'] = ['SimHei'] #配置中文显示


# plt.subplot(2,2,1)
# plt.plot(data['moth'],data['orderAmounts/moth'],c='blue')
# plt.title('未来每月消费总金额')
#
#
# plt.subplot(2,2,2)
# plt.plot(data['moth'],data['orderNums/moth'],c='red')
# plt.title('未来每月订单量')
#
# plt.subplot(2,2,3)
# plt.plot(data['moth'],data['userNums/moth'],c='green')
# plt.title('未来每月顾客量')

plt.plot(data['moth'],data['orderAmounts/moth'],c='blue',marker='o',markersize=3)

# plt.plot(data['moth'], y1, marker='o', markersize=3,c='red')  # 绘制折线图，添加数据点，设置点的大小


for a, b in zip(data['moth'],data['orderAmounts/moth']):
    plt.text(a, b, '{:.0f}'.format(b), ha='center', va='bottom', fontsize=20)  # 设置数据标签位置及大小

plt.suptitle('CDNOW未来每月营业额',fontsize=20)
plt.savefig('E:/program_workspace/pycharm_workspace/CDNOW/visualization/predict_company_next_salesPlus.jpg')
plt.show()


# 由此图像可看出，CDNOW公司的顾客数、订单数、订单金额未来十个月还是整体呈下降趋势
# 而且在1999年3月份会迎来最低谷，各方面都遭遇前所未有的萧条
# 所以结合CDNOW公司之前的营销数据和未来10个月的预测数据来看，CDNOW只迎来了短暂的最初三个月的春天，之后一直在下滑
# 从行业趋势和公司发展来看，或许CD电商前途渺茫，CDNOW公司面临困境
# 具体绘图保存到predict_company_next_sales.jpg图片中，后续方便查看
# 折线图


print('successfully!')