
import pandas as pd
from matplotlib import pyplot as plt
import warnings
warnings.filterwarnings('ignore')
#设定绘图风格
plt.style.use('ggplot')


data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\cluster_customer.xlsx',
                                                                    sheet_name='sheet1')


new_data = data.groupby(['cluster_label']).agg({'user_id':'count'})
print(new_data.dtypes)


plt.figure(figsize=(12,10))
plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
plt.suptitle('不同价值顾客占比',fontsize=30)
labels = list(range(5))
plt.pie(new_data,autopct='%.2f%%',colors=['yellow','green','blue','gray','red'],radius=1.5)
kinds = ['一次性顾客','老顾客','普通顾客','会员','至尊会员']
plt.legend(kinds,fontsize= 15)
plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\cluster_customer_label.jpg')
plt.show()


# 在这里我基于kmeans聚类分析再次将顾客分为5大类，简单可视化展示后
# 将绘图保存为cluster_customer_label.jpg文件，以便查看


print('successfully!')