
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from mpl_toolkits.mplot3d import Axes3D

data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\grou'
                                  'ped_user.xlsx',sheet_name='sheet1')

data = data[['shopping_times','order_num','order_amount']]


mode = KMeans(n_clusters=5,random_state=9)

mode.fit(data)

print(mode.cluster_centers_)
data['label'] = mode.labels_
print(data.head())

x1 = data[data['label']==0]
x2 = data[data['label']==1]
x3 = data[data['label']==2]
x4 = data[data['label']==3]
x5 = data[data['label']==4]

fig = plt.figure(figsize=(10,10))
plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
ax = fig.add_subplot(222, projection='3d')

ax = Axes3D(fig)

ax.scatter(x1['shopping_times'],x1['order_num'],x1['order_amount'],c='red')
ax.scatter(x2['shopping_times'],x2['order_num'],x2['order_amount'],c='green')
ax.scatter(x3['shopping_times'],x3['order_num'],x3['order_amount'],c='blue')
ax.scatter(x4['shopping_times'],x4['order_num'],x4['order_amount'],c='yellow')
ax.scatter(x5['shopping_times'],x5['order_num'],x5['order_amount'],c='black')

ax.set_title('顾客聚类',fontsize=30)
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# ax.set_xlim(min(data['shopping_times']),max(data['shopping_times']))
# ax.set_ylim(min(data['order_num']),max(data['order_num']))
# ax.set_zlim(min(data['order_amount']),max(data['order_amount']))

ax.set_xlim(0,40)
ax.set_ylim(0,500)
ax.set_zlim(0,1100)

plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\cluster_customer2.jpg')
plt.show()


# mode = KMeans(n_clusters=5,random_state=20)
#
# mode.fit(data)
#
# data['label'] = mode.labels_

# x1 = data[data['label']==0]
# x1 = x1[x1['order_amount']>=14]
# x1 = x1[x1['order_amount']<=16]
# # print(x1.describe())
# x2 = data[data['label']==1]
# x2 = x2[x2['order_amount']>=290]
# x2 = x2[x2['order_amount']<=400]
# # print(x2.describe())
# x3 = data[data['label']==2]
# x3 = x3[x3['order_amount']>=2500]
# x3 = x3[x3['order_amount']<=3000]
# # print(x3.describe())
# x4 = data[data['label']==3]
# x4 = x4[x4['order_amount']>=5000]
# x4 = x4[x4['order_amount']<=7000]
# # print(x4.describe())
# x5 = data[data['label']==4]
# x5 = x5[x5['order_amount']>=900]
# x5 = x5[x5['order_amount']<=1200]
# # print(x5.describe())
#
# fig = plt.figure(figsize=(10,10))
# plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
# ax = fig.add_subplot(222, projection='3d')
#
# ax = Axes3D(fig)
#
# ax.scatter(x1['shopping_times'],x1['order_num'],x1['order_amount'],c='red',marker='*')
# ax.scatter(x2['shopping_times'],x2['order_num'],x2['order_amount'],c='green',marker='^')
# ax.scatter(x3['shopping_times'],x3['order_num'],x3['order_amount'],c='blue')
# ax.scatter(x4['shopping_times'],x4['order_num'],x4['order_amount'],c='red')
# ax.scatter(x5['shopping_times'],x5['order_num'],x5['order_amount'],c='blue',marker='+')
#
# ax.set_title('顾客聚类',fontsize=30)
# ax.set_xlabel('购物次数',fontsize=15)
# ax.set_ylabel('订单数',fontsize=15)
# ax.set_zlabel('消费金额',fontsize=15)
#
# ax.set_xlim(0,200)
# ax.set_ylim(0,1000)
# ax.set_zlim(0,1200)

# plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\cluster_customer2.jpg')
# plt.show()


new_data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\grou'
                                  'ped_user.xlsx',sheet_name='sheet1')
new_data['cluster_label'] = mode.labels_
new_data.sort_values(by=['cluster_label'],inplace=True,ascending=False)


# 将聚类好的带上标签的数据保存到excel文件中，顾客按优先级从高到低进行排序
new_data.to_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\cluster_customer.xlsx',
                                     sheet_name='sheet1',index=False)



# 这第二章图是放大之后的聚类结果，几乎只看得见3个簇，但其实有5个，
# 通过放大数据能稍微明显的看出聚类结果，也就是对用户的分类
# 最后将带有标签的数据又保存到excel表格中，可以看到，每行（每个顾客）已经被标上号[0~4]


print('successfully!')