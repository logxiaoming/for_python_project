
import math
import pandas as pd
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score


data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\grouped_user.xlsx',sheet_name='sheet1')


x = data[['shopping_times','order_num']]
y = data['order_amount']


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2)


lasso = Lasso(alpha=1,max_iter=1000)

for i in range(5):
    lasso.fit(x_train,y_train)


score = lasso.score(x_train,y_train)
print('score of test set is:%.4f'%(score))


y_test_predict = lasso.predict(x_test)
mse = mean_squared_error(y_test,y_test_predict)



test = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\\alter_data\\100customer_data.xls',
                     sheet_name='Sheet1')


real_test = test['order_amount']
predict_feature = test[['shopping_times','order_num']]


predict_test = lasso.predict(predict_feature)
r2 = r2_score(y_true=real_test,y_pred=predict_test)
print('r2 score is:%.4f'%(r2))
print('mean_squared_erro is:%.4f'%(6.6563))


predict_test = pd.DataFrame(predict_test )
temp_data =pd.DataFrame()
temp_data['real'] = real_test
temp_data['predict'] = predict_test


# temp_data.to_csv('E:\program_workspace\pycharm_workspace\CDNOW\data\predict_100customer_sales.csv',
#                  index=False,sep='\t',float_format='%.2f')



print('successfully!')