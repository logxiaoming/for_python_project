
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('E:\program_workspace\pycharm_workspace\CDNOW\data\predict_100customer_sales.csv',
                   sep='\s+')


# 先把100个顾客消费的预测值和真实值都绘制出来，双折线图，保存到predict_100customer_sales.jpg文件中
# x = range(0,100)
# y1 = data['real']
# y2 = data['predict']
#
# plt.figure(figsize=(18,15))
# plt.title('预测值&真实值')
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.xlabel('顾客拟编号')
# plt.ylabel('消费额')
#
#
#
# plt.plot(x, y1, marker='o', markersize=3,c='red')  # 绘制折线图，添加数据点，设置点的大小
# plt.plot(x, y2, marker='o', markersize=3,c='black')
#
#
# for a, b in zip(x, y1):
#     plt.text(a, b, b, ha='center', va='bottom', fontsize=10)  # 设置数据标签位置及大小
# for a, b in zip(x, y2):
#     plt.text(a, b, b, ha='center', va='bottom', fontsize=10)
#
#
# plt.legend(['真实值', '预测值'])  # 设置折线名称
#
# plt.tight_layout()
# plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\predict_100customer_sales.jpg')
# plt.show()  # 显示折线图


# 为了更直观的看数据，取前5位顾客的消费数据绘制成折线图，清晰的反映预测值和真实值之间的差异
x = range(1,6)
y1 = data['real'][:5]
y2 = data['predict'][:5]

plt.figure(figsize=(14,10))
plt.title('预测值&真实值',fontsize=30)
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.xlabel('顾客拟编号',fontsize=15)
plt.ylabel('消费额',fontsize=15)


plt.plot(x, y1, marker='o', markersize=3,c='red')  # 绘制折线图，添加数据点，设置点的大小
plt.plot(x, y2, marker='o', markersize=3,c='black')


for a, b in zip(x, y1):
    plt.text(a, b, b, ha='center', va='bottom', fontsize=10)  # 设置数据标签位置及大小
for a, b in zip(x, y2):
    plt.text(a, b, b, ha='center', va='bottom', fontsize=10)

plt.legend(['真实值', '预测值'])  # 设置折线名称

plt.tight_layout()
plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\predict_5customer_sales.jpg')
plt.show()  # 显示折线图



print('successfully!')