
import copy
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split
import pandas as pd


# 读取数据集
data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\\train_month_data.xlsx','sheet1')


# 手动设置特征向量和标签值
x = data.iloc[:,1:3]
y = data.iloc[:,3]


# 划分训练集和测试集
x_train,x_test,y_train,y_test = train_test_split(x,y, test_size=0.2)


# 生成并训练模型，设置基本参数
lasso = Lasso(alpha=0.0001,max_iter=10000)
for i in range(5):
    lasso.fit(x,y)


# 测试集的分数
print('**********************************')
print("test set score:{:.2f}".format(lasso.score(x_test,y_test)))
# print("test set score:{:.2f}".format(lasso.score(x_train,y_train)))


# 打开新的文件，读取新的预测集
predict = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\predict_comp'
                        'any_next_10moth_sales.xlsx',sheet_name='sheet1')
pre_data = copy.deepcopy(predict)


# 划分预测集的特征矩阵
x_predict = predict.iloc[:,1:3]


# 开始预测
y_predict = lasso.predict(x_predict)
# print(y_predict[:1])
predict['orderAmounts/moth'] = y_predict


# 最后一步，保存预测的结果供后面可视化

# predict.to_excel("E:\program_workspace\pycharm_workspace\CDNOW\dat    # 这种方法会覆盖掉原来的数据
#           a\predict_data.xlsx",sheet_name='sheet2')


# 用writer，分别写入原来的sheet1和新增的sheet2作对比
writer = pd.ExcelWriter('E:\program_workspace\pycharm_workspace\CDNOW\data\predict_company_next_10moth_sales.xlsx')
pre_data.to_excel(writer,sheet_name='sheet1')
predict.to_excel(writer, sheet_name='sheet2')
writer.save()


# 简单预测了CDNOW公司在未来10个月的营收情况，保存为predict_company_next_10moth_sales.xlsx文件以便后续分析



print('successfully!')





