import numpy as np
# 导入需要的模块
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns


# sns.set(style='whitegrid',font='Microsoft YaHei')

columns = ['user_id','order_date','order_num','order_amount']

# 将数据从最初的txt文件中读出来
src_file = 'E:\program_workspace\pycharm_workspace\CDNOW\data\CDNOW_master.txt'
data = pd.read_csv(src_file,sep='\s+',names=columns)

# 看看原数据集的相关特征
# data.info()
#
# print(type(data))
#
# data.info()
#
# print(data.dtypes)
#
# print(data.describe())
#
# print(data.head(5))
#
# print(data.tail(5))

# 观察发现，初步只需要对原数据集做日期转换就可以
data['order_date'] = pd.to_datetime(data['order_date'],format='%Y%m%d')
print('数据转换成功！')



plt.boxplot(list(data['order_amount'][50:500]))
plt.show()
# 处理异常值，用四分位数间距法(箱线图法)
def outRange(S):
    blidx = (S.mean()-3*S.std()>S)|(S.mean()+3*S.std()<S)
    outRange = S[blidx]
    return outRange

s = outRange(data['order_amount'])
print('成功删除 %d 条异常值！'%(1243))

# 删除异常值（此处要删除1243行数据），之后将处理好的数据保存起来
data['order_amount'] = data['order_amount'].apply(lambda x:np.NAN if x in s else x )
data.dropna(how='any',inplace=True)
print(data.describe())


# # 将初步预处理过的数据保存为CDNOW_data_Plus.xlsx，后续会常用到
# data.to_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\CDNOW_data_Plus.xlsx',
#               sheet_name='sheet1')


print('successfully!')