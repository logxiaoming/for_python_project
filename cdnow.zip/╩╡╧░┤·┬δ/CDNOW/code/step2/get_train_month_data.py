
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

#设定绘图风格
plt.style.use('ggplot')

# sns.set(style='whitegrid',font='Microsoft YaHei')
sns.set(style='whitegrid',font='./myfont.TTF')

columns = ['user_id','order_dt','order_num','order_amount']

data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\CDNOW_data_Plus.xlsx',
                     'sheet1',names=columns)

print(data.head())


# 原数据集有很多弊端，不利于后续操作，所以我们可以先按照用户id分组

grouped_user = data.groupby('user_id').agg({'user_id':'count',
                                          'order_num':'sum',
                                          'order_amount':'sum',
                                           })
grouped_user = grouped_user.rename(columns={'user_id':'shopping_times'})

print(grouped_user.describe())

sum(data['order_amount'])


# step1
# 从分组后的数据描述中可以得到以下信息：
# 1，原数据集总共有69659行，4列；
# 2，原数据集包含23570个用户，订单时间横跨18个月，
# 总消费金额达到￥2500315.6300004106；
# 3，顾客平均购买2.955409次，平均消费￥106.080426；
# 4，顾客最大购买次数远远大于平均值，比前四分之三的数据都大，
# 说明会对数据分析带来一定的干扰，后期需要处理掉；


# step2
# 现在来处理掉数据集中的个别差异太大的数据，防止后续预测的时候造成太大干扰
# 我才去的策略是删除顾客人均消费额上下波动超过100的数据
# 并且删除最大消费额和最小消费额

k = grouped_user['order_amount'].mean()
print(k)

data.drop(data[data['order_amount'] > k+100].index,inplace=True)

data.drop(data[data['order_amount'] < k-100].index,inplace=True)

print(data.describe())


# step3
# 按月份将data分组，正式得到训练集
data['moth'] = data['order_dt'].astype('datetime64[M]')

print(data.head())

train_moth_data = data.groupby('moth').agg({'user_id':'count',
                                          'order_num':'sum',
                                          'order_amount':'sum',
                                           })
train_moth_data = train_moth_data.rename(columns={'user_id':'userNums/moth',\
                        'order_num':'orderNums/moth','order_amount':'orderAmounts/moth'})

print(train_moth_data.head())

print(train_moth_data.describe())



# step4
# 将用户按id号分好类之后转储到新的文件中，便于后续可视化和训练模型；
# 生成数据总览图，也保存起来；
# 此次保存的文件还经过差异值处理，把个差异太大的数据处理掉了
# 此数据集overView_train_moth_data仅供预测的部分使用
# 保存grouped_user数据和它的总览数据overView_grouped_user
# 保存train_moth_data数据和它的总览数据overView_train_moth_data

overView_grouped_user = grouped_user.describe()

overView_train_moth_data = train_moth_data.describe()

print(overView_grouped_user)

print(overView_train_moth_data)


overView_grouped_user.to_excel(excel_writer='E:\program_workspace\\'
                                            'pycharm_workspace\CDNOW\data\overView_grouped_user.xlsx',
              sheet_name='sheet1')

grouped_user.to_excel(excel_writer='E:\program_workspace\pycharm_workspace\CDNOW\data\grouped_user.xlsx',
              sheet_name='sheet1')

overView_train_moth_data.to_excel(excel_writer='E:\program_workspace\\'
                                               'pycharm_workspace\CDNOW\data\overView_train_moth_data.xlsx',
              sheet_name='sheet1')

train_moth_data.to_excel(excel_writer='E:\program_workspace\pycharm_workspace\\'
                                      'CDNOW\data\\train_month_data.xlsx',
              sheet_name='sheet1',columns=['userNums/moth','orderNums/moth','orderAmounts/moth'])



print('successfully!')