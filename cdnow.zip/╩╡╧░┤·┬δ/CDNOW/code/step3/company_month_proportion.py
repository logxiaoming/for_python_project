import pandas as pd
import numpy as np
from datetime import datetime
from matplotlib import pyplot as plt
import seaborn as sns
import os
import warnings
warnings.filterwarnings('ignore')
#设定绘图风格
plt.style.use('ggplot')


sns.set(style='whitegrid',font='./myfont.TTF')


data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\\train_month_dataPlus.xlsx',
                     'Sheet1')


plt.figure(figsize=(16, 12))
plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
plt.suptitle('CDNOW每季营业额',fontsize=30)


plt.subplot(1,2,1)
plt.plot(data['season'],data['orderAmounts/moth'],c='blue')
plt.title('每季度收入变化趋势')


plt.subplot(1,2,2)
labels=data['season']
plt.pie(data['orderAmounts/moth'],labels=labels,autopct='%1.2f%%')
plt.title('每季营收占比')


# plt.tight_layout()   # 这里如果铺满反而效果不好
plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\company_month_proportionPlus.jpg')
plt.show()


# 从图中得知，CDNOW的营销额只有1997年1月到4月收入比较可观，后续一直在呈下降趋势
# CD唱片公司几乎只迎来了短暂的春天，后续一直处于萧条时期
# 绘图保存为company_month_proportion.jpg文件，便于后续分析


print('successfully!')