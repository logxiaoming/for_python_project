
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

#设定绘图风格
plt.style.use('ggplot')

# sns.set(style='whitegrid',font='Microsoft YaHei')
sns.set(style='whitegrid',font='./myfont.TTF')


data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\grouped_user.xlsx',
                     'sheet1')
data = data.iloc[:20,:]

plt.figure(figsize=(16, 12))
plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
# plt.suptitle('每个顾客在CDNOW的消费情况',fontsize=30)

plt.subplot(1,2,1)
plt.plot(data['user_id'],data['shopping_times'],c='red',alpha=0.6)
plt.title('顾客购买次数',fontsize=20)
plt.xlabel('顾客id',fontsize=16)
plt.ylabel('消费次数',fontsize=16)

# plt.subplot(2,2,2)
# plt.scatter(data['user_id'],data['order_num'],c='blue',alpha=0.6)
# plt.title('顾客订单数量',fontsize=20)
# plt.xlabel('顾客id')
# plt.ylabel('订单数')

plt.subplot(1,2,2)
plt.plot(data['user_id'],data['order_amount'],c='green',alpha=0.6)
plt.title('顾客消费金额',fontsize=20)
plt.xlabel('顾客id',fontsize=16)
plt.ylabel('消费金额',fontsize=16)

plt.tight_layout()
plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\each_customer_paidPlus.jpg')
plt.show()


# 这张图展示了每个顾客的消费情况，包括订单数、消费次数、消费金额，
# 从图中可得知，大多顾客的消费次数在25次以下，订单数在80次以下，消费金额在600以下
# 图片保存为each_customer_paid.jpg，方便后续分析

print('successfully!')
