
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
from  matplotlib import cm
#设定绘图风格
plt.style.use('ggplot')

# sns.set(style='whitegrid',font='Microsoft YaHei')
sns.set(style='whitegrid',font='./myfont.TTF')

columns = ['user_id','order_dt','order_products','order_amount']

data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\CDNOW_data_Plus.xlsx',
                     'sheet1',names=columns)

rfm = pd.pivot_table(data, index='user_id',
                    values=['order_dt', 'order_amount', 'order_products'],
                    aggfunc={'order_dt':'max',
                            'order_amount':'sum',
                            'order_products':'count'})
rfm['R'] = (rfm.order_dt.max()-rfm.order_dt)/np.timedelta64(1,'D')
rfm.rename(columns={'order_amount':'M', 'order_products':'F'}, inplace=True)

def rfm_func(x):
    level = x.apply(lambda x: '1' if x>=0 else '0')
    label = level.R + level.F + level.M
    d = {
        '111':'重要价值客户',
        '011':'重要保持客户',
        '101':'重要挽留客户',
        '001':'重要发展客户',
        '110':'一般价值客户',
        '010':'一般保持客户',
        '100':'一般挽留客户',
        '000':'一般发展客户'
    }
    return d[label]

rfm['label'] = rfm[['R','F','M']].apply(lambda x: x-x.mean()).apply(rfm_func, axis=1)

rfm_sum = rfm.groupby('label').agg({'R':'count','F':'sum','M':'sum'})

plt.figure(figsize=(12,12))

patches, l_text, p_text = plt.pie(rfm_sum['R'],
                                   labels=rfm_sum.index,
                                   explode = (0, 0, 0, 0,0, 0, 0, 0),
                                   colors = cm.rainbow(np.arange(len(rfm_sum['R']))/len(rfm_sum['R'])),
                                   labeldistance=1.1,
                                   autopct = '%3.1f%%',
                                   shadow = False,
                                   textprops = {'fontsize':12},
                                   startangle = 0,
                                   pctdistance = 0.9)

plt.rcParams['font.family'] = ['SimHei'] #配置中文显示

for t in l_text:
        t.set_size = 30
for t in p_text:
        t.set_size = 20
plt.title("RFM分层用户数占比", fontsize=20)

plt.axis('equal')
plt.legend( bbox_to_anchor=(1.6, 0.7))

plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\customer_retain.jpg')
plt.show()


# 从图中可知，大部分顾客都只消费了一次，回头率很低，
# 重点挽留顾客少之又少，很难有较大群体持续为公司提供营收来源
# 再次反映了当时CDNOW公司的收入很不可观，几乎持续低迷，顾客太少
# 绘图保存为customer_retain.jpg文件，以便后续分析


print('successfully!')
