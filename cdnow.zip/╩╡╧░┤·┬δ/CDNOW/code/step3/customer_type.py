import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib as mpl
from matplotlib import pyplot as plt
import seaborn as sns
import os
import warnings
warnings.filterwarnings('ignore')

# sns.set(style='whitegrid',font='Microsoft YaHei')
# sns.set(style='whitegrid',font='./myfont.TTF')

# columns = ['用户ID','购买日期','订单数','订单金额']

data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\CDNOW_data_Plus.xlsx',
                     'sheet1')


grouped_user = data.groupby('user_id').agg({'user_id':'count', 'order_num':'sum', 'order_amount':'sum'})

message = list(grouped_user.agg({'user_id':'count', 'order_num':'sum', 'order_amount':'sum'}))

mean = list(grouped_user.agg({'order_num':'mean', 'order_amount':'mean'}))



user_type = data.groupby('user_id').sum()
mean_order_num = user_type['order_num'].mean()
mean_order_value = user_type['order_amount'].mean()

all_value_customer = user_type['order_num'][user_type['order_num'] >= mean_order_num ].count() +\
      user_type['order_amount'][user_type['order_amount'] >= mean_order_value ].count()

comm_customer = data['user_id'].count()

# 用饼图显示普通顾客和value顾客占比
# 这里将订单金额大于平均值或者总订单数大于平均值的顾客归为 value顾客
plt.figure(figsize = (11,11))
plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
labels = ['普通顾客','价值顾客']
explode = (0,0.1)
plt.pie([comm_customer,all_value_customer],labels = labels,explode = explode,autopct = '%1.2f%%')
plt.suptitle('价值顾客&普通顾客占比',fontsize=35)

plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\common&value_customer.jpg')
plt.show()

# 从图中可知，大部分顾客消费很少，几乎1/2顾客都只消费了一次，只有%14.21的顾客消费量高一些
# 由此，公司想要增加营收其中必不可少的就是先牢牢稳住这部分老顾客，通过优惠活动，安抚老顾客，
# 提高公司的口碑，让他们帮忙宣传，同时尽可能吸引更多顾客
# 最后将绘图保存到common&value_customer.jpg中以便后续观察


print('successfully!')