import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib as mpl
from matplotlib import pyplot as plt
import seaborn as sns
import os
import warnings
warnings.filterwarnings('ignore')

# sns.set(style='whitegrid',font='Microsoft YaHei')
sns.set(style='whitegrid',font='./myfont.TTF')


data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\CDNOW_data_Plus.xlsx',
                     'sheet1')

# 用散点图显示订单数跟订单金额的关系
plt.figure(figsize=(16, 8))
plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
plt.title('订单金额-订单数')
plt.scatter(data['order_num'],data['order_amount'],c='red',alpha=0.6)
plt.legend(['订单数','订单金额'])
plt.xlabel('订单数')
plt.ylabel('订单金额')
# plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\orders&money.jpg')
plt.show()


# 从图中我们可以看出，订单金额跟订单数总体呈现一个正相关，线性变化，
# 订单最少都是1，此时订单金额最小为0；订单较大的比如100，此时订单金额为1300
# 由此得出：总体来说，顾客数越多，订单数也越多，订单金额就越大
# 将绘图保存为orders&money.jpg，以便后续观察


print('successfully!')

