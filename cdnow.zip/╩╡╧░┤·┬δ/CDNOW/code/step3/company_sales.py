
import pandas as pd
import numpy as np
from datetime import datetime
from matplotlib import pyplot as plt
import seaborn as sns
import os
import warnings
warnings.filterwarnings('ignore')
from  matplotlib import cm
#设定绘图风格
plt.style.use('ggplot')


# sns.set(style='whitegrid',font='Microsoft YaHei')
sns.set(style='whitegrid',font='./myfont.TTF')

columns = ['user_id','order_dt','order_products','order_amount']

data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\CDNOW_data_Plus.xlsx',
                     'sheet1',names=columns)

data['month'] = data.order_dt.values.astype('datetime64[M]')

grouped_month = data.pivot_table(index='month',
              values=[ 'order_amount', 'order_products', 'user_id'],
              aggfunc={'order_amount':'sum',
                       'order_products':'sum',
                      'user_id':'count'})
grouped_month['user_sum'] = data.groupby('month').user_id.apply(lambda x:len(x.drop_duplicates()))

plt.figure(figsize=(16, 12))

plt.rcParams['font.family'] = ['SimHei'] #配置中文显示
plt.subplot(2,2,1)
grouped_month.order_amount.plot(title='每月消费总金额')

plt.subplot(2,2,2)
grouped_month.order_products.plot(title='每月订单量')

plt.subplot(2,2,3)
grouped_month.user_id.plot(title='每月顾客量')


plt.suptitle('CDNOW每月营销情况',fontsize=20)
plt.savefig('E:/program_workspace/pycharm_workspace/CDNOW/visualization/company_month_sales.jpg')
plt.show()


# 由此图像可看出，CD的顾客数、订单数、订单金额从1997年一月到三月持续上升，到三月份到达极值，
# 之后就起伏不定，但总体呈下降趋势，而且下降幅度大，1998年6月营业额就降到70000左右
# 具体绘图我已经保存到company_month_salse.jpg图片中，后续方便查看
# 折线图

print('successfully!')