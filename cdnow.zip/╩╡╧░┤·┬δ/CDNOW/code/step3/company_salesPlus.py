
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')


#设定绘图风格
plt.style.use('ggplot')

data = pd.read_excel('E:\program_workspace\pycharm_workspace\CDNOW\data\\train_month_data.xlsx',
                     'sheet1')

plt.rcParams['font.sans-serif']=['SimHei'] # 解决中文乱码

labels = data['moth']
a = data['userNums/moth']
b = data['orderNums/moth']
c = data['orderAmounts/moth']

x = np.arange(len(labels))  # 标签位置
width = 0.25  # 柱状图的宽度

fig, ax = plt.subplots(figsize=(18,13))
rects1 = ax.bar(x - width*2, a, width, label='用户数')
rects2 = ax.bar(x - width+0.01, b, width, label='订单数')
rects3 = ax.bar(x + 0.02, c, width, label='金额')

# 为y轴、标题和x轴等添加描述
ax.set_ylabel('值', fontsize=16)
ax.set_xlabel('月份', fontsize=16)
ax.set_title('CDNOW每月营销情况改进版',fontsize=30)
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()   # 显示右上角图例

def autolabel(rects):
    """在*rects*中的每个柱状条上方附加一个文本标签，显示其高度"""
    for rect in rects:
        height = rect.get_height()
        ax.annotate('%.2f'%(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3点垂直偏移
                    textcoords="offset points",
                    ha='center', va='bottom')

autolabel(rects1)
autolabel(rects2)
autolabel(rects3)

# 自动调整子图参数以提供指定的填充。多数情况下没看出来区别
fig.tight_layout()

plt.savefig('E:\program_workspace\pycharm_workspace\CDNOW\\visualization\company_month_salesPlus.jpg')
plt.show()

# 这张图用柱状图显示了公司每个月的营销情况，直白的告诉我们各项指标的数目
# 很容易对比出哪几个月的销量好，哪几个月CDNOW到了惨淡期
# 柱状图


print('successfully!')