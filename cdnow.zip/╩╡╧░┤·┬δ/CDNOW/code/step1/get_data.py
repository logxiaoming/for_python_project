
# 导入需要的模块
import requests
from bs4 import BeautifulSoup
import wget
import zipfile

url='http://www.brucehardie.com/datasets/'

# 这个网页没有反爬机制，所以这里不用设置请求头
response=requests.get(url=url)

html = response.content.decode('utf-8')

soup = BeautifulSoup(html,'html.parser')

link = soup.find_all('a')

data_name = ''

for tag in link:
    if 'master' in tag.get('href'):
        data_name = (tag.get('href'))

# print(data_name)

download_link = url + data_name

# 下载数据，不要重复执行！
# 先指定保存的路径：
path = 'E:\program_workspace\pycharm_workspace\CDNOW\data'
wget.download(download_link, path)  # 下载

print(download_link)

# 压缩文件路径
zip_path = path + '\\' + data_name
# print(zip_path)

# 解压到此目录下
winrar_pth = path

file = zipfile.ZipFile(zip_path)

# 解压文件
print('开始解压...')

file.extractall(winrar_pth)

print('解压结束！')
# 关闭文件流
file.close()

print('successfully!')