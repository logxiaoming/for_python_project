# import time
# import turtle
# from math import *
# from turtle import *
#
# import matplotlib.pyplot as plt
#
# home()
# speed(0)
# r = 260  # 大小 圆设置
# x = 2
# screensize(400, 300, "black")
# y = x * r
# z = sqrt(pow(r, 2) + pow(y, 2))
# w = 40
# pu()
# right(90)
# fd(240)
# left(90)
# pd()
# fillcolor("red")
# begin_fill()
# circle(r)
# end_fill()
#
# pu()
# left(90)
# fd(r)
# # 复位中心上键
# # print(pos())(显示坐标)
# speed(0)
# width(7)
# for i in range(6):
#     right(60 + 90)  # 六边
#     fd(y)
#     right(90)
#     fd(z)
#     left(90)
#     pd()
#     circle(z)
#     pu()
#     # 取线
#     left(90)
#     fd(z)
#     left(90)
#     fd(y)
#     right(90)
# fd(w)
# # 内小圆
# left(90)
# pd()
# fillcolor("red")  # 内小圆颜色
# begin_fill()
# print(pos())
# circle(w)
# end_fill()
# # circle(w)
# left(90)
# pu()
# fd(w)
# left(90)
# fd(39)
# pd()
# fillcolor("black")
# begin_fill()
# goto(0, 220)
# goto(-40, 20)
# pu()
# goto(20, 20 * sqrt(3) + 20)
# end_fill()
# pd()
# fillcolor("black")
# begin_fill()
# goto(100 * sqrt(3), -80)
# goto(-20, 20 - 20 * sqrt(3))
# pu()
# goto(20, 20 - 20 * sqrt(3))
# end_fill()
# pd()
# fillcolor("black")
# begin_fill()
# goto(-100 * sqrt(3), -80)
# goto(-20, 20 * sqrt(3) + 20)
# pu()
# goto(0, 20)
# end_fill()
# goto(0, 60)
# right(180)
# fillcolor("red")  # 内小圆颜色
# begin_fill()
# print(pos())
# circle(w)
# end_fill()
# hideturtle()  # 隐藏海龟
# # 新赤
#
#
# # time.sleep(10)
# #
# # turtle.hideturtle()
# exitonclick()
# plt.show()
#
#
# print('successfully!')
#

# class Rectangle:
#     def __init__(self,l,w):
#         self.__length = l
#         self.__width = w
#     def area(self):
#         return self.__length * self.__width
#     def perimeter(self):
#         return 2*self.__length + 2 * self.__width
# #下面是测试代码
# l = eval(input("请输入长方形的长"))
# w = eval(input("请输入长方形的宽"))
# q1 = Rectangle(l,w)
# print(q1.area())
# print(q1.perimeter())

for i in range(100):
    for j in range(100):
        print(i+j)

# a = 1
# print(a)