
import cv2
import keyboard
print('opencv:'+cv2.__version__)


# demon1 仅仅是在图片上画矩形而已
# demon1 测试如何在用python读取\打开图片

img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\image1.jpg')

# img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\image5.jpg')


x, y, w, h = 280, 100, 100, 100

cv2.rectangle(img,(x,y,100+w,y+h),color=(0,0,255),thickness=2)

gray_img = cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
cv2.imshow('gray',gray_img)

# cv2.imshow('best look',img)

if keyboard.is_pressed('enter') :
    exit(0)

cv2.waitKey(0)


cv2.destroyAllWindows()

print('successfully!')