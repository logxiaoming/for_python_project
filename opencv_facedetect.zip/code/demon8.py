
# 识别摄像头中的人脸

import cv2
import keyboard
print('opencv:'+cv2.__version__)


# 首先自己定义数据集中id编号和名字的映射关系,id号在此字典中的图像表示可以识别
klara = [2, 3, 4, 5, 6]
xiaoming = [ 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

# 加载人脸识别器(级联分类器)
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
video_capture = cv2.VideoCapture(0)

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\trainer\\train1.yml')


while True:
    flag, img = video_capture.read()
    if not flag:
        break
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray_img, scaleFactor=1.25, minNeighbors=5, minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE)

    for x, y, w, h in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)

        id, confidence = recognizer.predict(gray_img[y:y + h, x:x + w])

        if id in klara:
            name = 'klara'
        elif id in xiaoming:
            name = 'xiaoming'
        else:
            name = 'unknown'

        cv2.putText(img, name, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 255), 1)

    # 这里最好把这两个函数放在内层循环，每读取到一帧图片后就显示该图片
    cv2.imshow('person',img)

    cv2.waitKey(3)


    # 同样地,按下回车键整个程序结束
    if keyboard.is_pressed('enter'):
        exit(0)


video_capture.release()

cv2.destroyAllWindows()

print('successfully!')