
import cv2
import keyboard
import time

print('opencv:'+cv2.__version__)


# 这一步是整个项目最有意思的时刻,从此刻开始正式可以真正意义上的识别一张图片,当然能否识别出来那得看你的数据集质量和规模
# 类似的原理,可以检测图片,视频,摄像头等数据源


# 首先自己定义数据集中id编号和名字的映射关系,id号在此字典中的图像表示可以识别
# names = dict({1:'administrator xiaoming', 2:'klara', 3:'klara', 4:'klara', 5:'klara', 6:'klara'})
xiaoming = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
klara = [21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40]



# 创建识别器和分类器,并让识别器加载训练好的模型,这里就不需要再单独训练
recognizer = cv2.face.LBPHFaceRecognizer_create()
face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
# recognizer.read('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\trainer\\train1.yml')  # 加载第一个模型
recognizer.read('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\trainer\\train2.yml')   # 加载第二个模型




# 手动指定待识别图片
# srcPath = 'E:/program_workspace/pycharm_workspace/openCV_targetTrack/faces/'
# tail = input('input image name:')
# img = cv2.imread(srcPath + tail + '.jpg')

# 默认待识别图片
img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\faces\\22.jpg')
# img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\faces\\23.jpg')
# img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\faces\\8.jpg')
# img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\image8.jpg')
# img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\faces\\14.jpg')
# img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\faces\\16.jpg')

# 此时给定一张陌生的图片
# img = cv2.imread("E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\image7.jpg")

# img = cv2.resize(img, dsize=(600,450))


start = time.time()
# 同样地,将图片灰化处理,加速识别
gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
face = face_detector.detectMultiScale(gray,scaleFactor=1.25, minNeighbors=1)


for x, y, w, h in face:
    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 0, 255), 2)

    # 调用模型的predict函数,识别目标图片,返回值id(识别结果标签)和confidence(识别置信度评分)
    # confidence用来衡量识别结果与原有模型之间的距离,小于50分一般可以接受;值越大表示跟目标差距大,识别结果不太好
    id, confidence = recognizer.predict(gray[y:y+h, x:x+w])


    # 到字典中去找到目标图片的名字(如果识别该图片到属于数据集)
    if confidence<80:
        if id in xiaoming:
            name = 'xiaoming'
        elif id in klara:
            name = 'klara'
        else:
            name = 'unknown'

    else:
        name = 'unknown'

    conf = '{:.2f}%'.format(100 - confidence)

        # if confidence < 80:
        #     idum = names[idnum]
        #     confidence = "{0}%".format(round(100 - confidence))
        # else:
        #     idum = "unknown"
        #     confidence = "{0}%".format(round(100 - confidence))
        # cv2.putText(img, str(idum), (x + 5, y - 5), font, 1, (0, 0, 255), 1)
        # cv2.putText(img, str(confidence), (x + 5, y + h - 5), font, 1, (0, 0, 0), 1)


    print('id:%d' % id)
    print('name:%s' % name)
    print('confidence:%s' % conf)


    # 这一步至关重要,在图像窗口中显示图片对象的名字,显示在矩形框上面,可以调整字体颜色,大小,厚度等参数
    cv2.putText(img, name, (x+5, y-5), cv2.FONT_HERSHEY_SIMPLEX, 0.625, (0, 255, 0), 1)
    cv2.putText(img,str(conf),(x+5,y+h-5),cv2.FONT_HERSHEY_SIMPLEX, 0.625, (0, 255, 0), 1)

end = time.time()

cv2.imshow('person', img)


# 同样地,按下回车键整个程序结束
if keyboard.is_pressed('enter'):
    exit(0)

cv2.waitKey(0)

cv2.destroyAllWindows()

print('runtime is %.4f'%(end-start))
print('successfully!')