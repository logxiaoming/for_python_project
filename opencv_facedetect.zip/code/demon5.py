
import os
import cv2
import numpy as np
from PIL import Image

# 这一步具体讲述如何用人脸数据集来提取图像特征,训练模型,保存模型(*.yml)
# 图像识别是将图像每个像素点,也就是所谓的特征给提取出来,以数组的形式传入模型训练,
# 最终将训练好的模型直接保存到.yml文件中,下次用于识别时直接加载模型来使用即可,
# 由于我的数据集都比较小,所以整个程序运行几乎一瞬间就结束,但当大数据集的时候就会显得吃力,而且我电脑上还没有GPU加速


def getImageAndLabels(path):
    faceSamples = []
    ids = []

    # 加载数据集目录
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]


    face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


    # 读取每一张图片,解析图片
    for imagepath in imagePaths:
        PIL_image = Image.open(imagepath).convert('L')
        img_numpy = np.array(PIL_image,'uint8')
        faces = face_detector.detectMultiScale(img_numpy)


        # id = int(imagepath.split('\\')[-1].split('.')[0])
        id = int(os.path.split(imagepath)[-1].split(".")[0])


        # 将每一张图片的特征保存到列表中,并且保存对应的 id 编号
        for x,y,w,h in faces:
            faceSamples.append(img_numpy[y:y+h,x:x+w])
            ids.append(id)

    # print('id:',ids)
    # print('fs:',faceSamples)

    return faceSamples, ids



if __name__ =='__main__':

    # 输入数据集所在的目录
    # path = 'E:\program_workspace\pycharm_workspace\openCV_targetTrack\\faces'        #第一个模型
    path = 'E:\program_workspace\pycharm_workspace\openCV_targetTrack\\train_image'     #第二个模型

    # 返回两个数组,包含数据集中图片的id和特征向量
    faces, ids = getImageAndLabels(path)
    # print(len(faces),len(ids))

    # 加载识别器模型,
    recognizer = cv2.face.LBPHFaceRecognizer_create()

    # 开始训练模型,id部分得传入多维数组,(不认列表)
    for i in range(10):
        recognizer.train(faces, np.array(ids))   # 第一个参数是人脸特征，第二个参数是每张图片对应的编号
        print('train once again!')


    # 把训练好的模型保存好,下次需要使用的时候直接加载
    # recognizer.write('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\trainer\\train1.yml')   #第一个模型
    recognizer.write('E:\program_workspace\pycharm_workspace\openCV_targetTrack\\trainer\\train2.yml')     #第二个模型


    print('successfully!')


