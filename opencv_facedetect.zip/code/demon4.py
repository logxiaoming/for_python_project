
import cv2
print('opencv'+cv2.__version__)

# demon4 也比较重要,它负责录入人脸数据,训练数据集生成人脸特征并保存起来
# 后续给定图片还是视频,都要根据保存的特征集来识别,
# 此程序介绍用本地摄像头录入人脸数据,当然如果已经下载好了数据集那就不用管这一步


cap = cv2.VideoCapture(0)


flat = 1
num = 11  # 新录入照片时必须注意这个数字

while cap.isOpened():
    ret, frame = cap.read()
    cv2.imshow('faces',frame)
    k = cv2.waitKey(1) & 0xFF
    if k == ord('2'):
        # 用imwrite 方法将当前读取到的图片保存到人脸数据集
        cv2.imwrite('E:/program_workspace/pycharm_workspace/openCV_targetTrack/train_image/'+str(num)+'.jpg',frame)
        print('successfully add user'+str(num))
        num+=1
    elif k == ord('1'):
        break

cap.release()

cv2.destroyAllWindows()