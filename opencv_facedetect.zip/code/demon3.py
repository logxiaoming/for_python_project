

import cv2
import keyboard

print('opencv:'+cv2.__version__)

# 从 demon3 开始就比较有意思了,这时候可以检测视频中的人脸,而且可以选择打开自己的的摄像头
# 这部分我会详细注释,搞清楚视频人脸检测的操作步骤



# 加载人脸分类器,用默认的就好
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


# 打开视频文件（或者可以使用本地摄像头,也可以用）
video_capture = cv2.VideoCapture(0)
# video_capture = cv2.VideoCapture('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\\vedio1.mp4')
# video_capture = cv2.VideoCapture('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\\vedio2.mp4')
# video_capture = cv2.VideoCapture('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\\vedio3.mp4')
# video_capture = cv2.VideoCapture('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\\vedio4.mp4')


# 循环一帧一帧地读取视频数据
while True:
    # ret为boolean类型,表示有没有读取到图片; frame为当前这一帧的图像
    ret, frame = video_capture.read()
    frame = cv2.flip(frame,1)
    if not ret:
        break
    # 将帧转换为灰度图像（加速人脸检测）
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 检测人脸,这里通常需要调整参数,但区别也不太大,可以手动尝试
    faces = face_cascade.detectMultiScale(gray_frame,scaleFactor=1.25,minNeighbors=3, minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE )


    # 在人脸周围绘制矩形
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 3)  #里面的参数比较简单,org参数通常为固定写法

    # 显示结果
    cv2.imshow('Baby', frame)

    # 这里关于waitKey函数的用法详解:
    # cv2.waitkey(delay)，delay的单位为ms毫秒，当delay取大于0的值时，程序在给定的delay时间内等待用户按键触发，如果用户没有按下键，则继续等待下一个delay时间(
    # 循环)，直到用户按键触发，退出程序。若设置delay为0，则表示必须点击窗口界面的×才能关闭程序。若设置delay的值小于0，等待键盘按键，任何一个按键都会关闭程序，默认参数为小于0。
    # 不带参数表示，从键盘输入任何字符，都会关闭打开的窗口
    cv2.waitKey(1)

    # 当键盘按下回车键整个程序就结束,打开的图像窗口也就跟着关闭了
    if keyboard.is_pressed('enter') :
        exit(0)


# 最后别忘了关闭视频资源或者释放摄像头
video_capture.release()

# 同样地,回收opencv环境
cv2.destroyAllWindows()


print('successfully!')