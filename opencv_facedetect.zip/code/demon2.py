

import cv2
import keyboard
print('opencv:'+cv2.__version__)

# demon2 可以实现检测到多个人脸
# 从dimon2 开始就需要自己定义人脸检测函数以及给detectMultiScale 函数调整参数,不同的参数会导致不同的检测效果
# 但总的来说,我作为一个初学者只是简单调用opencv库进行人脸识别等,并没有对算法\识别率做进一步研究和改进


def face_detect_function(img):
    face_detect = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    # .image：表示的是要检测的输入图像
    # 2.scaleFactor：表示每次图像尺寸减小的比例
    # 3. minNeighbors：至少检测次数。若为3，表示每一个目标至少要被检测到3次才算是真的目标(表示要求越高)
    face = face_detect.detectMultiScale(img,1.20,3,0)

    for x,y,w,h in face:
        cv2.rectangle(img, (x, y),( x + w, y + h), color=(0,0,255), thickness=3)
    # new_img = cv2.resize(img,(1100,700))
    new_img = cv2.resize(img, (0, 0), fx=0.5, fy=0.5)
    cv2.imshow('best look', new_img)

if __name__=='__main__':

    # img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\image2.jpg')  # 识别我的毕业照
    img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\image4.jpg') #识别我的亲人合照
    # img = cv2.imread('E:\program_workspace\pycharm_workspace\openCV_targetTrack\data\image5.jpg') #识别我的亲人合照

    # 为了识别准确，这里将图片灰化处理再识别
    gray = cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
    face_detect_function(gray)

    if keyboard.is_pressed('enter'):
        exit(0)

    cv2.waitKey(0)

    cv2.destroyAllWindows()

    print('successfully!')
