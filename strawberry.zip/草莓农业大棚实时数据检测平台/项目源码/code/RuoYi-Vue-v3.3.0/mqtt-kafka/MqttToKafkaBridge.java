import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import org.eclipse.paho.client.mqttv3.MqttClientPersistence;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.Properties;

public class MqttToKafkaBridge {

    public static void main(String[] args) throws MqttException {
        String mqttBrokerUrl = "tcp://localhost:1883"; // MQTT服务器IP地址
        String mqttTopic = "mqtt-topic";//mqtt 主题
        String kafkaBrokerUrl = "localhost:9092"; // Kafka 服务器地址
        String kafkaTopic = "mqtt-topic"; // Kafka 主题

        // 启动 MQTT 消费者并将消息转发到 Kafka
        startMqttConsumerAndForwardToKafka(mqttBrokerUrl, mqttTopic, kafkaBrokerUrl, kafkaTopic);
    }

    public static void startMqttConsumerAndForwardToKafka(String mqttBrokerUrl, String mqttTopic, String kafkaBrokerUrl, String kafkaTopic) throws MqttException {
        MqttClientPersistence persistence = new MemoryPersistence();
        MqttClient mqttClient = new MqttClient(mqttBrokerUrl, MqttClient.generateClientId(), persistence);

        MqttConnectOptions connOpts = new MqttConnectOptions();
        connOpts.setCleanSession(true);
        mqttClient.connect(connOpts);

        mqttClient.subscribe(mqttTopic, (topic, msg) -> {
            String messageContent = new String(msg.getPayload());
            System.out.println("Received message from MQTT: " + messageContent);

            // 配置 Kafka 生产者
            Properties kafkaProps = new Properties();
            kafkaProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBrokerUrl);
            kafkaProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            kafkaProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

            KafkaProducer<String, String> kafkaProducer = new KafkaProducer<>(kafkaProps);

            // 转发消息到 Kafka
            ProducerRecord<String, String> record = new ProducerRecord<>(kafkaTopic, messageContent);
            kafkaProducer.send(record, (metadata, exception) -> {
                if (exception != null) {
                    exception.printStackTrace();
                } else {
                    System.out.println("Message forwarded to Kafka topic: " + kafkaTopic);
                }
            });

            kafkaProducer.close();
        });

        System.out.println("MQTT Consumer started and listening to topic: " + mqttTopic);
    }
}
