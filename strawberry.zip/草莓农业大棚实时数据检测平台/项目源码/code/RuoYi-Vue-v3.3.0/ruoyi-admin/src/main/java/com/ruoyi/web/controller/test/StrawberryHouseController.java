package com.ruoyi.web.controller.test;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ruoyi.common.utils.DateUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.test.domain.StrawberryHouse;
import com.ruoyi.test.service.IStrawberryHouseService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * testStrawController
 * 
 * @author jxh
 * @date 2024-07-20
 */
@RestController
@RequestMapping("/test/test")
public class StrawberryHouseController extends BaseController
{
    @Autowired
    private IStrawberryHouseService strawberryHouseService;

    /**
     * 查询testStraw列表
     */
    @PreAuthorize("@ss.hasPermi('test:test:list')")
    @GetMapping("/list")
    public TableDataInfo list(StrawberryHouse strawberryHouse,
                              @RequestParam(value = "startTime",required = false)String startTime,
                              @RequestParam(value = "endTime",required = false) String endTime)
    {
        startPage();

        if (startTime != null && endTime != null){
            /*newStartTime = DateUtils.dataConvert(startTime);
            newEndTime = DateUtils.dataConvert(endTime);*/

            strawberryHouse.setTime(DateUtils.dateTime(new Date()));
            strawberryHouse.setStartTime(startTime);
            strawberryHouse.setEndTime(endTime);
        }

        List<StrawberryHouse> list = strawberryHouseService.selectStrawberryHouseList(strawberryHouse);
        return getDataTable(list);
    }

    /**
     * 导出testStraw列表
     */
    @PreAuthorize("@ss.hasPermi('test:test:export')")
    @Log(title = "testStraw", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(StrawberryHouse strawberryHouse)
    {
        List<StrawberryHouse> list = strawberryHouseService.selectStrawberryHouseList(strawberryHouse);
        ExcelUtil<StrawberryHouse> util = new ExcelUtil<StrawberryHouse>(StrawberryHouse.class);
        return util.exportExcel(list, "test");
    }
    /**
     * 获取testStraw详细信息
     */

    @PreAuthorize("@ss.hasPermi('test:test:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return AjaxResult.success(strawberryHouseService.selectStrawberryHouseById(id));
    }

    /**
     * 新增testStraw
     */
    @PreAuthorize("@ss.hasPermi('test:test:add')")
    @Log(title = "testStraw", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody StrawberryHouse strawberryHouse)
    {
        return toAjax(strawberryHouseService.insertStrawberryHouse(strawberryHouse));
    }

    /**
     * 修改testStraw
     */
    @PreAuthorize("@ss.hasPermi('test:test:edit')")
    @Log(title = "testStraw", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody StrawberryHouse strawberryHouse)
    {
        return toAjax(strawberryHouseService.updateStrawberryHouse(strawberryHouse));
    }

    /**
     * 删除testStraw
     */
    @PreAuthorize("@ss.hasPermi('test:test:remove')")
    @Log(title = "testStraw", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(strawberryHouseService.deleteStrawberryHouseByIds(ids));
    }

    //@PreAuthorize("@ss.hasPermi('test:test:getRecentStrawberryHouse')")
    @GetMapping("/getRecentStrawberryHouse")
    public List<StrawberryHouse> getLastTemperature(
            @RequestParam("largeshelfid") String largeshelfid) {
       List<StrawberryHouse> house = strawberryHouseService.selectRecentStrawberryHouse(largeshelfid);
       return house;
    }


}
