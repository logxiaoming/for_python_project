package com.ruoyi.web.controller.strawberry;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.strawberry.domain.StrawberryGreenhouse;
import com.ruoyi.strawberry.service.IStrawberryGreenhouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 草莓大棚Controller
 * 
 * @author ruoyi
 * @date 2024-07-17
 */
@RestController
@RequestMapping("/strawberry/greenhouse")
public class StrawberryGreenhouseController extends BaseController
{
    @Autowired
    private IStrawberryGreenhouseService strawberryGreenhouseService;

    /**
     * 查询草莓大棚列表
     */
    @PreAuthorize("@ss.hasPermi('strawberry:greenhouse:list')")
    @GetMapping("/list")
    public TableDataInfo list(StrawberryGreenhouse strawberryGreenhouse)
    {
        startPage();
        List<StrawberryGreenhouse> list = strawberryGreenhouseService.selectStrawberryGreenhouseList(strawberryGreenhouse);
        return getDataTable(list);
    }

    /**
     * 导出草莓大棚列表
     */
    @PreAuthorize("@ss.hasPermi('strawberry:greenhouse:export')")
    @Log(title = "草莓大棚", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(StrawberryGreenhouse strawberryGreenhouse)
    {
        List<StrawberryGreenhouse> list = strawberryGreenhouseService.selectStrawberryGreenhouseList(strawberryGreenhouse);
        ExcelUtil<StrawberryGreenhouse> util = new ExcelUtil<StrawberryGreenhouse>(StrawberryGreenhouse.class);
        return util.exportExcel(list, "greenhouse");
    }

    /**
     * 获取草莓大棚详细信息
     */
    @PreAuthorize("@ss.hasPermi('strawberry:greenhouse:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return AjaxResult.success(strawberryGreenhouseService.selectStrawberryGreenhouseById(id));
    }

    /**
     * 新增草莓大棚
     */
    @PreAuthorize("@ss.hasPermi('strawberry:greenhouse:add')")
    @Log(title = "草莓大棚", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody StrawberryGreenhouse strawberryGreenhouse)
    {
        return toAjax(strawberryGreenhouseService.insertStrawberryGreenhouse(strawberryGreenhouse));
    }

    /**
     * 修改草莓大棚
     */
    @PreAuthorize("@ss.hasPermi('strawberry:greenhouse:edit')")
    @Log(title = "草莓大棚", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody StrawberryGreenhouse strawberryGreenhouse)
    {
        return toAjax(strawberryGreenhouseService.updateStrawberryGreenhouse(strawberryGreenhouse));
    }

    /**
     * 删除草莓大棚
     */
    @PreAuthorize("@ss.hasPermi('strawberry:greenhouse:remove')")
    @Log(title = "草莓大棚", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(strawberryGreenhouseService.deleteStrawberryGreenhouseByIds(ids));
    }
}
