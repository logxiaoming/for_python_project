import com.sun.xml.internal.ws.api.model.ExceptionType;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;


public class task1_map extends Mapper<LongWritable, Text,Text, LongWritable> {

    private static final Log LOG = LogFactory.getLog(task1_map.class);


    protected void map(LongWritable key,Text value,Context context)
    throws IOException,InterruptedException{

        String line = value.toString();

        LOG.info("Debugging information: " + line);


//        String[] row = StringUtils.split(line,",");
        String[] row = line.split(",");

        String city = row[0].trim();
//        double sales = Double.parseDouble(row[3]);
        long sales = Long.parseLong(row[3]);

//      try to print the line:
        System.out.println(line);
        System.out.println("map is ok!");

        context.write(new Text(city),new LongWritable(sales));

    }
}
