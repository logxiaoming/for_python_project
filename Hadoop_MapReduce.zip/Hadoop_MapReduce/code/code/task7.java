import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


class task7 {

    public static class PharmacyMapper extends Mapper<LongWritable, Text, Text, LongWritable> {

        private Text date = new Text();
        private LongWritable patient = new LongWritable();
        SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM");
        Date tempdate = null;

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

            String[] line = value.toString().split(",");

            if (line.length == 6) {
                String temp = line[2].toString();

                try {

                    tempdate = parser.parse(temp);

                } catch (ParseException e) {
                    e.printStackTrace();
                }

                date.set(tempdate.toString());

                patient.set(Long.parseLong(line[5]));

                context.write(date,patient);

            } else {
                System.out.println("wrong input!");
            }
        }
    }

    public static class PharmacyReducer extends Reducer<Text, LongWritable, Text, LongWritable> {

        private LongWritable result = new LongWritable();

        public void reduce(Text key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {

            long sum = 0;

            for (LongWritable value : values) {
                sum += value.get();
            }

            result.set(sum);

            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Pharmacy Revenue Analysis");

        job.setJarByClass(PharmacyRevenueAnalysis.class);


        job.setMapperClass(PharmacyMapper.class);
        job.setReducerClass(PharmacyReducer.class);


        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);

        String src = "hdfs://master:9000";


        Scanner sc = new Scanner(System.in);
        System.out.print("inputPath:");
        String inputPath = sc.next();
        System.out.print("outputPath:");
        String outputPath = sc.next();

        FileInputFormat.setInputPaths(job, new Path(src + inputPath));

        FileOutputFormat.setOutputPath(job, new Path(src + outputPath));

        job.waitForCompletion(true);
//        System.exit(job.waitForCompletion(true) ? 0 : 1);

        System.out.println("successfully!");




    }
}

