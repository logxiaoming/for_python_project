import com.sun.xml.bind.v2.schemagen.xmlschema.List;

import java.util.Comparator;

public class debug_sort implements Comparator<String>{
    @Override
    public int compare(String a,String b) {
        String[] line1 = a.split("\\s+");
        String[] line2 = b.split("\\s+");

        double x = Double.parseDouble(line1[1]);
        double y = Double.parseDouble(line1[1]);

        return Double.compare(x,y);
    }

}
