//import org.apache.commons.httpclient.URI;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.protocol.datatransfer.PacketHeader;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import javax.xml.soap.Text;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadHDFSFileWithoutMap {

    public static void main(String[] args) throws IOException {


//        String hdfsFilePath = "hdfs://master:9000/mapreduce/newinput/data.txt";
//        String hdfsFilePath = "/mnt/cgshare/data.txt";
        String hdfsFilePath = "/mapreduce/newinput/data.txt";

//        Configuration conf = new Configuration();
//        FileSystem fs = FileSystem.get(conf);

        try {

//            (FSDataInputStream inputStream = fs.open(new Path(hdfsFilePath));


//            FileSystem fs = FileSystem.get(new URI("hdfs://master:9000"),new Configuration());
            FileSystem fs = null;
            try {
                fs = FileSystem.get(new URI("hdfs://master:9000"),
                        new Configuration());
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }

            FSDataInputStream is = fs.open(new Path(hdfsFilePath));

            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String line;
            while ((line = reader.readLine()) != null) {
                    String[] row = line.split(",");

//                System.out.println(row[0]);
//                System.out.println(row[3]);
                System.out.println(line);
            }
            fs.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
