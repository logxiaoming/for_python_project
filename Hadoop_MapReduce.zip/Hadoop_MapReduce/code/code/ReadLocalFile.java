import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadLocalFile {

    public static void main(String[] args) {

        String filePath = "/mnt/cgshare/input/data.txt";

        try (FileReader fileReader = new FileReader(filePath);
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] item = line.split(",");
//                System.out.println(item[5]);
                System.out.println(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
