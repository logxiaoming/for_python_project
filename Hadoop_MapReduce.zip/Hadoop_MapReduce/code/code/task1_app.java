import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.protocol.datatransfer.PacketHeader;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import javax.xml.soap.Text;
import java.io.IOException;
import java.net.URI;
import java.util.Scanner;

public class task1_app {
    public static void main(String[] args) throws IOException,ClassNotFoundException
    ,InterruptedException{

        Configuration conf = new Configuration();

        Job job = Job.getInstance(conf);



        job.setJarByClass(task1_app.class);

        job.setMapperClass(task1_map.class);
        job.setReducerClass(task1_reduce.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongWritable.class);

        Scanner sc = new Scanner(System.in);

//        System.out.print("inputPath:");
//        String inputPath = sc.next();
        System.out.print("outputPath:");
        String outputPath = sc.next();

        String inputPath = "/mnt/cgshare/input";

        FileInputFormat.setInputPaths(job,new Path(inputPath));

        FileOutputFormat.setOutputPath(job,new Path(outputPath));

        job.waitForCompletion(true);

        System.out.println("successfully!");

//        try{
//            FileSystem fs = FileSystem.get(new URI("hdfs://master:9000"),
//                    new Configuration());
//            Path srcPath = new Path(outputPath+"/part-r-00000");
//
//            FSDataInputStream is = fs.open(srcPath);
//            System.out.println("result:");
//
//            while(true){
//                String line = is.readLine();
//                if(line ==null){
//                    break;
//                }
//                System.out.println(line);
//            }
//            is.close();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
    }
}
