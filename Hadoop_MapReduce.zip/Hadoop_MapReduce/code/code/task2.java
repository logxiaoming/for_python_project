import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

class task2 {

    public static class PharmacyMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

        private Text city = new Text();

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

            String[] tokens = value.toString().split(",");

            if (tokens.length == 6) {
                city.set(tokens[1].trim());
                context.write(city, new IntWritable(1));
            } else {
                System.out.println("wrong input!");
            }
        }
    }

    public static class PharmacyReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

        private IntWritable result = new IntWritable();

        public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {

            int count = 0;

            for (IntWritable value : values) {
                count += value.get();
            }

            result.set(count);

            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Pharmacy Revenue Analysis");

        job.setJarByClass(PharmacyRevenueAnalysis.class);


        job.setMapperClass(PharmacyMapper.class);
        job.setReducerClass(PharmacyReducer.class);


        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        String src = "hdfs://master:9000";

//        String inputPath = "/mnt/cgshare/input";
//        String outputPath = "/mnt/cgshare/output/output7";

        Scanner sc = new Scanner(System.in);
        System.out.print("inputPath:");
        String inputPath = sc.next();
        System.out.print("outputPath:");
        String outputPath = sc.next();

        FileInputFormat.setInputPaths(job,new Path(src+inputPath));

        FileOutputFormat.setOutputPath(job,new Path(src+outputPath));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}

