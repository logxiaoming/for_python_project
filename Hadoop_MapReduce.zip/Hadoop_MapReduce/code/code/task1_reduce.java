import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Reducer;

import javax.xml.soap.Text;
import java.io.IOException;

public class task1_reduce extends Reducer<Text,LongWritable,Text, DoubleWritable> {
    public void reduce(Text key,Iterable<LongWritable> value,Context context)
    throws IOException,InterruptedException {

        long sum = 0;
        long count = 0;
        for (LongWritable sales: value){
            sum += sales.get();
            count++;
        }
        double avg = sum / count;

        context.write(key,new DoubleWritable(avg));

    }
}
