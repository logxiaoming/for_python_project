
//1,import package which project needs
import java.io.IOException;
import java.util.Scanner;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.Writable;

class PharmacyRevenueAnalysis {

//    2,redefine Map class
    public static class PharmacyMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {

        private Text city = new Text();
        private DoubleWritable revenue = new DoubleWritable();

        @Override
//        3,override the map function
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

            String[] tokens = value.toString().split(",");

//            map the (key,values) to reduce
            if (tokens.length == 6) {
                city.set(tokens[0].trim());
                revenue.set(Double.parseDouble(tokens[3].trim())); // %:value
                context.write(city, revenue);
            } else {
               System.out.println("wrong input!");
            }
        }
    }

//    4,redifine the reduce class
    public static class PharmacyReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {

        private DoubleWritable result = new DoubleWritable();

        @Override
//        5,override the function reduce
        public void reduce(Text key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
            double sum = 0.0;
            int count = 0;


            for (DoubleWritable value : values) {
                sum += value.get();
                count++;
            }


            double averageRevenue = sum / count;
            result.set(averageRevenue);

            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Pharmacy Revenue Analysis");

        job.setJarByClass(PharmacyRevenueAnalysis.class);


        job.setMapperClass(PharmacyMapper.class);
        job.setReducerClass(PharmacyReducer.class);


        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        String src = "hdfs://master:9000";


        Scanner sc = new Scanner(System.in);
        System.out.print("inputPath:");
        String inputPath = sc.next();
        System.out.print("outputPath:");
        String outputPath = sc.next();

        FileInputFormat.setInputPaths(job,new Path(src+inputPath));

        FileOutputFormat.setOutputPath(job,new Path(src+outputPath));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}

