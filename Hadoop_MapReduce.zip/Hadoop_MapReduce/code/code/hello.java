import sun.awt.X11.XSystemTrayPeer;

public class hello {
    public static void main(String[] args)
    {
        String hello = "hello IDEA!";
        System.out.println(hello);
    }

}

