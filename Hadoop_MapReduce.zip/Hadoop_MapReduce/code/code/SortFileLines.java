import java.io.*;
import java.util.*;

class myComparator implements Comparator<String>{
    @Override
    public int compare(String a,String b) {
        String[] line1 = a.split("\t");
        String[] line2 = b.split("\t+");

        double x = Double.parseDouble(line1[1]);
        double y = Double.parseDouble(line2[1]);


        return x-y>0?-1:1;
    }

}


public class SortFileLines {
    public static void main(String[] args) {

        String inputFilePath = "/mnt/cgshare/newoutput/task1_output/part-r-00000";
        String outputFilePath = "/mnt/cgshare/newoutput/task1_output/part-r-00000";

        try {

            List<String> lines = readLinesFromFile(inputFilePath);

            Collections.sort(lines, new myComparator());

            writeLinesToFile(outputFilePath, lines);

            System.out.println("File sorted successfully!");

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    private static List<String> readLinesFromFile(String filePath) throws IOException {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

    private static void writeLinesToFile(String filePath, List<String> lines) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        }
    }
}
