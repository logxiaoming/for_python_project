import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import sun.util.resources.cldr.ig.LocaleNames_ig;

class task6 {

    public static class PharmacyMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {

        private Text date = new Text();
        private DoubleWritable sales = new DoubleWritable();

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

            String[] line = value.toString().split(",");

            if (line.length == 6) {

                date.set(line[2].trim());

                sales.set(Double.parseDouble(line[3]));

                context.write(date,sales);

            } else {
                System.out.println("wrong input!");
            }
        }
    }

    public static class PharmacyReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {

        private DoubleWritable result = new DoubleWritable();

        public void reduce(Text key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {

            double sum = 0;

            for (DoubleWritable value : values) {
                sum += value.get();
            }

            result.set(sum);

            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Pharmacy Revenue Analysis");

        job.setJarByClass(PharmacyRevenueAnalysis.class);


        job.setMapperClass(PharmacyMapper.class);
        job.setReducerClass(PharmacyReducer.class);


        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        String src = "hdfs://master:9000";

//        String inputPath = "/mnt/cgshare/input";
//        String outputPath = "/mnt/cgshare/output/output7";

        Scanner sc = new Scanner(System.in);
        System.out.print("inputPath:");
        String inputPath = sc.next();
        System.out.print("outputPath:");
        String outputPath = sc.next();

        FileInputFormat.setInputPaths(job, new Path(src + inputPath));

        FileOutputFormat.setOutputPath(job, new Path(src + outputPath));

        System.exit(job.waitForCompletion(true) ? 0 : 1);

        System.out.println("successfully!");


    }
}

