import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class wcmap extends Mapper<LongWritable, Text,Text,LongWritable> {
 public void map(LongWritable key,Text value,Context context)
 throws IOException,InterruptedException {

        String line = value.toString();
        String[] arr = StringUtils.split(line," ");

        System.out.println(line);

        for (String s :arr){
         context.write(new Text(s), new LongWritable(1));
        }


 }
}
