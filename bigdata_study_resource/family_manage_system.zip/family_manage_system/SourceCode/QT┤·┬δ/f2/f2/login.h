#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include<QPainter>   #include<QString
#include<QDebug

#include<QMessageBox>   
#include<QIcon>
#include"treedisplay.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Login; }
QT_END_NAMESPACE

public:
    Login(QWidget *parent = nullptr);
    ~Login();
    void paintEvent(QPaintEvent *event);   
drawpixmap

public slots:
    void on_btn_login_clicked();

    void on_btn_out_clicked();

pubulic:
    Ui::Login *ui;
    TreeDisplay page1;
};
#endif // LOGIN_H
