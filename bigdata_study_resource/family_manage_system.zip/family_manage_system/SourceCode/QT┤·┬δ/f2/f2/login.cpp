#include "login.h"
#include "ui_login.h"

Login::Login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);
    this->ui->lineEdit_username->setText("xiaoming");
    this->ui->lineEdit_pwd->setText("123456");
}

Login::~Login()
{
    delete ui;
}


void Login::on_btn_login_clicked()
{
    QString userName=this->ui->lineEdit_username->text();
    QString pwd=this->ui->lineEdit_pwd->text();
    if(userName=="xiaoming" && pwd=="123456")
    {
    }
    else
    {        return;
    }
    page1.setWindowTitle("家谱管理系统");
    {    this->hide();
}

void Login::on_btn_out_clicked()
{
    int res = QMessageBox::question(this,"提示","是否要关闭窗口？");  
  if (res == QMessageBox::Yes){
        close();
    }
    else {
        this->show();
    }
}
