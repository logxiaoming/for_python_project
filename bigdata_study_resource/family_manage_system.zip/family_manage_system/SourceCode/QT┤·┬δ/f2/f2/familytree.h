#ifndef TREEDISPLAY_H
#define TREEDISPLAY_H

#include <QWidget>

#include<QDebug>

#include<QTreeWidget>

#include<QTreeWidgetItem>

#include<QStringList>

#include<QMessageBox>

#include<QPaintEvent>

#include<QPainter>

#include"family.h"

namespace Ui {class TreeDisplay;}

class TreeDisplay : public QWidget
{
    Q_OBJECT
}

public:
    Family f1;      
    explicit TreeDisplay(QWidget *parent = nullptr);

    ~TreeDisplay(); 
   
 void InitTreeStructure();  

 void AddItemTest();      
   
    void InitAncestor(QString iname,QString isex,QString iage,QString
spouseName);  

QTreeWidgetItem* FindTreeItem(QString targetName,QTreeWidgetItem* father); 
     
  void InitMember(Member* father,Member* self); 
                                 
void paintEvent(QPaintEvent *event);                        

public slots:
    void on_btn_add_clicked();  
    void on_treeWidget_itemClicked(QTreeWidgetItem *item, int column);
    void on_btn_change_clicked();    
   void on_btn_delete_clicked();   
    void on_btn_analysis_clicked();  
   void on_treeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column);
    void on_btn_refine_clicked();
    void on_btn_search_clicked();
     void on_pushButton_released();

public:
    Ui::TreeDisplay *ui;
    QTreeWidgetItem *topItem=nullptr;   
    QTreeWidgetItem* tempItem=nullptr;
    QTreeWidgetItem* AnoItem=nullptr;
};

#endif // TREEDISPLAY_H
