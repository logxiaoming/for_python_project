#ifndef FAMILY_H
#define FAMILY_H
#include<iostream>
#include<QString>
#include<QDebug>

struct Member:public QObjectUserData
{

    QString name;
    QString gender;
    int sexStatus;
    int age;
    QString spouseName;
    QString address;
    QString birth;

     //ָ��   
    int childrenAmount;
    Member * father;
    Member * brotherNext;
    Member * brotherPre;
    Member * child;
};

Q_DECLARE_METATYPE(Member);
Q_DECLARE_METATYPE(Member * );

class Family
{
public:

    Family();
    ~Family();

	//���ӳ�Ա
    void AddMember();

	//�ҵ���ǰ��Ա
    Member* FindMember(QString TarName,Member* key);

    void ChildrenInit();
	
	//��ʾ��Ϣ
    void ShowInfo();

    void FindAndShow();

	//������Ϣ
    void ChangeMemberInfo();

	//������Ա
    Person* CreateMember();

	//��ʾ����
    void ShowChild(Member* parent);

	//ɾ��ĳ����ͥ
    void DeleteSmallFamily(QString TarName);

	//ɾ��ĳ����Ա
    void DeleteMember(Member* p);

    Member* ancestor=new Member;

    int num=0;
};

#endif // FAMILY_H
