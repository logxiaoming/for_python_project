#include "login.h"
#include<QSplashScreen>
#include <QApplication>
#include<QDateTime>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QSplashScreen screen(pix);
    screen.show();
    a.processEvents();
        do{
        now=QDateTime::currentDateTime();
    } while (n.secsTo(now)<=5);
    Login w;
    w.show();

    screen.finish(&w);
    return a.exec();
}
