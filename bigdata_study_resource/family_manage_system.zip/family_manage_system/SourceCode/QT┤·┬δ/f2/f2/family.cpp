#include "family.h"


Family::Family()
{
    this->ancestor->name="";
    this->ancestor->gender="";
    this->ancestor->sexStatus=-1;
    this->ancestor->age=100;
    this->ancestor->spouseName="";
    this->ancestor->address="";
    this->ancestor->birth="";

    this->ancestor->child=nullptr;
    this->ancestor->childrenAmount=0;
    this->ancestor->father=nullptr;
    this->ancestor->brotherPre=nullptr;
    this->ancestor->brotherNext=nullptr;
    this->num++;
}

Family::~Family()
{

}

//寻找成员
Member* Family::FindMember(QString TarName, Member *key)
{
    Member* p = key;
    Member* ans = nullptr;
    Member* temp = p;

    if (p->name == TarName)
    {        return p;
    }
    while (temp->brotherNext != nullptr)
    {
        ans = FindMember(TarName,temp->brotherNext);
        if (ans != nullptr)
        {
            return ans;
        }
        temp = temp->brotherNext;
    }

    temp = p;
    if (temp->child != nullptr)
    {
        ans = FindMember(TarName,temp->child);
    }
    return ans;
}


Member* Family::CreateMember()
{
   Member* p = new Person;
    p->name = "";
    p->childrenAmount = 0;
    p->sex="";
    p->sexStatus=-1;
    p->age=100;
    p->spouseName="";
    p->address="";
    p->birth="";

    p->father = nullptr;
    p->child = nullptr;
    p->brotherPre = nullptr;
    p->brotherNext = nullptr;

    this->num++;
    return p;
}

void Family::DeleteSmallFamily(QString TarName)
{

  Member* p = FindMember(TarName, ancestor);

	//1
    if (p->brotherPre != nullptr && p->brotherNext != nullptr)
    {
        p->brotherPre->brotherNext = p->brotherNext;
        p->brotherNext->brotherPre = p->brotherPre;
        p->father->childrenAmount--;
    }

	//2
    if (p->brotherPre != nullptr && p->brotherNext == nullptr)
    {
        p->brotherPre->brotherNext = nullptr;
        p->father->childrenAmount--;
    }

	//3
    if (p->brotherPre == nullptr && p->brotherNext != nullptr)
    {
        p->father->child = p->brotherNext;
        p->brotherNext->brotherPre = nullptr;
        p->father->childrenAmount--;
    }

	//4
    if (p->brotherPre == nullptr && p->brotherNext == nullptr)
    {
        p->father->child = nullptr;
        p->father->childrenAmount--;
    }


    if (p->child != nullptr)
    {
        DeleteMember(p->child);
    }
    this->num--;

    delete(p);

}


void Family::DeleteMember(Member* p)
{
    Member* temp = p;   


    while (temp->brotherNext != nullptr)
    {
        temp = temp->brotherNext;       }


    while (temp->brotherPre !=nullptr)
    {
        temp = temp->brotherPre;    
        temp->brotherNext->brotherPre = nullptr;    
        temp->brotherNext->brotherNext = nullptr;

        DeleteMember(temp->brotherNext);
    }

    if (temp->child)
    {
        DeleteMember(temp->child);
    }
    this->num--;
    delete p;
}

