#include "treedisplay.h"
#include "ui_treedisplay.h"
#include "family.h"


TreeDisplay::TreeDisplay(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TreeDisplay)
{
    ui->setupUi(this);
    this->InitTreeStructure();

 TreeDisplay::~TreeDisplay()
{
    delete ui;
}

void TreeDisplay::InitTreeStructure()
{

    QStringList strList;
    strList<<"姓名"<<"性别"<<"年龄"<<"配偶姓名";
    this->ui->treeWidget->setHeaderLabels(strList);
}

void TreeDisplay::AddItemTest()
{
    QString name="张三";
    QString sex="�?;
    int age=20;
    QString agee=QString::number(age);
    QStringList testList;
    testList<<name<<sex<<agee;
    QTreeWidgetItem* item1=new QTreeWidgetItem(testList);
    this->ui->treeWidget->addTopLevelItem(item1);
}


void TreeDisplay::InitAncestor(QString iname, QString isex, QString iage,QString spouseName)
{
    QStringList strList;
    strList<<iname<<isex<<iage<<spouseName;


    this->f1.ancestor->name=iname;
    this->f1.ancestor->sex=isex;
    this->f1.ancestor->age=iage.toInt();
    this->->spouseName=spouseName;

    topItem=new QTreeWidgetItem(strList);
    this->ui->treeWidget->addTopLevelItem(topItem);

    topItem->setData(0,Qt::UserRole+1,QVariant::fromValue(f1.ancestor));
    Member* tem=topItem->data(0,Qt::UserRole+1).value<Member*>();
    qDebug()<<"背后的结点信�?"<<tem->name<<" "<<tem->sex<<" "<<tem->age;
    qDebug()<<topItem->text(0);
}

QTreeWidgetItem* TreeDisplay::FindTreeItem(QString targetName, QTreeWidgetItem *father)
{

    QTreeWidgetItem* p=father;
    QTreeWidgetItem* ans=nullptr;
    QTreeWidgetItem* temp=p;

    if(p->text(0)==targetName)          {
        qDebug()<<"找到�?;
        return p;
    }

     
    while(temp->child(0)!=nullptr)
    {
        int count=temp->childCount();   
        for(int i=0;i<count;i++)
        {
            ans=FindTreeItem(targetName,temp->child(i));    
            if(ans!=nullptr)
            {
                qDebug()<<"找到�?<<endl;
                return ans;
            }
        }
        temp=temp->child(0);
    }
    return ans;
}

void TreeDisplay::InitMember(Member *father, Member *self)
{
    QTreeWidgetItem* fa=FindTreeItem(father->name,this->topItem);
    QStringList strList;
    strList<<self->name<<self->sex<<QString::number(self->age)<<self->spouseName;

    QTreeWidgetItem* newItem=new QTreeWidgetItem(strList);
    fa->addChild(newItem);

    newItem->setData(0,Qt::UserRole+1,QVariant::fromValue(self));
    Person* tem=newItem->data(0,Qt::UserRole+1).value<Person*>();
    qDebug()<<"Behind:"<<tem->name<<" "<<tem->sex<<" "<<tem->age;

    Member* temp=father;
    temp = temp->child;
    if (father->child == nullptr)
    {
        father->child = self;
        return;
    }

    while (temp->brotherNext != nullptr)
    {
        temp = temp->brotherNext;
    }
    temp->brotherNext = self;
}

void TreeDisplay::paintEvent(QPaintEvent *event)
{
    QPainter p(this);

            p.end();
}

void TreeDisplay::on_btn_add_clicked()
{
    QString input_Name=this->ui->Edit_name->text();
    QString input_Father=this->ui->Edit_father->text();
    QString input_Sex=this->ui->Edit_sex->text();
    QString input_Age=this->ui->Edit_age->text();
    QString input_spouse=this->ui->Edit_spouse->text();


    if(input_Name=="")
    {
        int res = QMessageBox::critical(this,"提示","必须输入姓名�?);
        information 信息提示  question  询问
        return;
    }

    if(input_Sex!="�? && input_Sex!="�?)
    {
        int res = QMessageBox::critical(this,"提示","性别信息有误�?);
        return;
    }

    if(input_Father=="")
    {
        qDebug()<<"要添加的是祖�?;
        if(topItem!=nullptr)
        {
            int res = QMessageBox::critical(this,"提示","祖先已有�?);
            return;
        }
        InitAncestor(input_Name,input_Sex,input_Age,input_spouse);
        int res = QMessageBox::information(this,"提示","先祖结点添加成功�?);
        return ;
    }

    Member* p=f1.FindMember(input_Father,this->f1.ancestor);
    if(p==nullptr)
    {
        int res = QMessageBox::critical(this,"提示","父亲不存在！");
        return;
    }
    Member* newp=this->f1.CreateMember();
    newp->father=p;     //指定父亲  接链操作
    newp->name=input_Name;
    newp->age=input_Age.toInt();
    newp->sex=input_Sex;
    newp->spouseName=input_spouse;
    InitMember(p,newp);     
int res = QMessageBox::information(this,"提示","子代结点添加成功�?);
}


void TreeDisplay::on_treeWidget_itemClicked(QTreeWidgetItem *item, int column)
{
    
    this->ui->change_name->setText(item->text(0));
    this->ui->change_age->setText(item->text(2));
    this->ui->change_spouse->setText(item->text(3));
    this->tempItem=item;

    Member* tem=tempItem->data(0,Qt::UserRole+1).value<Person*>();
    qDebug()<<"Behind:"<<tem->name<<" "<<tem->gender<<" "<<tem->age;
}

void TreeDisplay::on_btn_change_clicked()
{
    if(tempItem==nullptr)
    {
        qDebug()<<"请选中要修改的结点";
        int res = QMessageBox::critical(this,"提示","请选中要修改的结点�?);
        return;
    }
    tempItem->setText(0,this->ui->change_name->text());
    tempItem->setText(2,this->ui->change_age->text());
    tempItem->setText(3,this->ui->change_spouse->text());

    Member* temm=tempItem->data(0,Qt::UserRole+1).value<Person*>();
    temm->name=this->ui->change_name->text();
    temm->age=this->ui->change_age->text().toInt();
    temm->spouseName=this->ui->change_spouse->text();
    int res = QMessageBox::information(this,"提示","修改成功�?);
}

void TreeDisplay::on_btn_delete_clicked()
{
    if(tempItem==nullptr)
    {
        qDebug()<<"请选中要修改的结点";
        int res = QMessageBox::critical(this,"提示","请选中要修改的结点�?);
        return;
    }

    if(tempItem==topItem)
    {
        qDebug()<<"祖先结点不可删除";
        int res = QMessageBox::critical(this,"提示","祖先结点不可删除�?);
        return;
    }
    QString TarName=tempItem->text(0);
    tempItem->parent()->removeChild(tempItem);
    this->f1.DeleteSmallFamily(TarName);
    tempItem=nullptr;
    int res = QMessageBox::information(this,"提示","删除成功�?);
}

void TreeDisplay::on_treeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
        Member* temm=tempItem->data(0,Qt::UserRole+1).value<Member*>();
    this->ui->label_name->setText(temm->name);
    this->ui->label_sex->setText(temm->sex);
    this->ui->Edit_birth->setText(temm->birth);
    this->ui->Edit_Address->setText(temm->address);
    
    AnoItem=item;
}

void TreeDisplay::on_btn_refine_clicked()
{
    QString n_Birth=this->ui->Edit_birth->text();
    QString n_Address=this->ui->Edit_Address->text();

    if(AnoItem==nullptr)
    {
        int res = QMessageBox::critical(this,"提示","请选中要完善的结点�?);
        return;
    }

Member* temm=AnoItem->data(0,Qt::UserRole+1).value<Person*>();
    temm->birth=n_Birth;
     temm->address=n_Address;
    int res = QMessageBox::information(this,"提示","完善成功�?);
}

void TreeDisplay::on_btn_search_clicked()
{
    QString TarName=this->ui->Edit_Search->text();
    if(TarName=="")
    {
        int res = QMessageBox::critical(this,"提示","请输入要查找的人的姓名！");
        return;
    }
    Member* temp=this->f1.FindMember(TarName,f1.ancestor);
    if(temp==nullptr)
    {
        int res = QMessageBox::critical(this,"提示","查无此人�?);
        return;
    }
    this->ui->search_name->setText(temp->name);
    this->ui->search_sex->setText(temp->sex);
    this->ui->search_spouse->setText(temp->spouseName);
    this->ui->search_age->setText(QString::number(temp->age));

    this->ui->search_address->setText(temp->address);
    
    this->ui->search_birth->setText(temp->birth);

}


void TreeDisplay::on_pushButton_released()
{
    close();
}
