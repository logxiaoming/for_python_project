#include "Member.h"
#include <iostream>
using namespace std;

//�ж�ÿ���¶�Ӧ������
int birtht::judgenumber(birtht b)
{
    if(b.m==2)
    {
      if((b.y%400==0) || (b.y%4==0) && (b.y%100!=0))
      {
          return 29;
      }
       else{
        return 28;
       }

    }
    else if(b.m==1||b.m==3||b.m==5||b.m==7||b.m==8||b.m==10||b.m==12)
    {
        return 31;
    }
    else {return 30;}

}

//�ж�����ĳ��������Ƿ�����Ϸ�
bool birtht::judgebirth(birtht b)
{
    if(b.y==0||b.m==0||b.d==0)
    {
        return 0;
    }
   if(b.y>2022)
   {
       return 0;
   }
   else if(b.m>12)
   {
       return 0;
   }
   else if(b.d>(judgenumber(b)))
   {
       return 0;
   }
   else {
        return 1;
   }

}


//�ж������Ӵ����������Ƿ�Ϸ�
bool Member::judgechil(birtht b,Member *p)
{
   int s=0;
   if(p->dad==NULL)
   {
       (p->dad->birth.y)=0000;
   }
   s=(p->birth.y) - (p->dad->birth.y);
   if(s<18)
   {
       return 0;
   }
   else
    {return 1;}

}

Member::Member()
{
    this->name="zhangsan";
    this->gender=1;
    this->birth.y=1900;
    this->birth.m=1;
    this->birth.d=1;
    this->num=0;
    this->dad=NULL;
    this->brothernext=NULL;
    this->brotherpre=NULL;
    this->child=NULL;
    //cout<<"hello";
}


Member::Member(string name,bool gender,birtht birth,int num, Member *dad,Member *brothernext,Member *brotherpre,Member *child)
{
       this->name=name;
       this->gender=gender;

       this->birth.y=birth.y;
       this->birth.m=birth.m;
       this->birth.d=birth.d;

       this->num=num;
       this->dad=dad;
       this->brothernext=brothernext;
       this->brotherpre=brotherpre;
       this->child=child;

}

Member::~Member()
{
        this->name=" ";

        this->birth.y=0000;
       this->birth.m=00;
       this->birth.d=00;

       this->gender=1;
       this->num=0;
       this->dad=NULL;
       this->brothernext=NULL;
       this->brotherpre=NULL;
       this->child=NULL;
}
/*Family::Family(Member *anc)
    {
       this->anc=new Member();
       this->anc->name="zhangsan";
       this->anc->birth=19490101;
       this->anc->gender=1;
       this->anc->num=0;
       this->anc->dad=NULL;
       this->anc->brothernext=NULL;
       this->anc->brotherpre=NULL;
       this->anc->child=NULL;
       cout<<"hello";
    }
Family::~Family()
{
    this->anc=NULL;

        delete anc;

}

//P��ʾ��Ա��Ϣ
void Family:: print_family_member()
    {
        cout<<"����������鿴�ĵ�����ͥ��Ա��"<<endl;
        string n;
        cin>>n;
        Member *p=findmember(n,anc);
        if(p==NULL)
        {
            cout<<"û����ˣ�"<<endl;
        }

        cout<<"������"<<p->name<<endl;
        if(p->gender==1)
        {
            cout<<"�Ա�"<<"��"<<endl;
        }
        else{
            cout<<"�Ա�"<<"Ů"<<endl;}
        cout<<"�������ڣ�"<<p->birth<<endl;

        if(p->num-1==0)
        {
            cout<<n<<"��û�к��"<<endl;
        }
        else{
            printchild(p);
        }

        return ;

    }

  void  Family::destroy(Member *p)
    {
       Member *temp=p;
       while(temp->brothernext)
       {
           temp=temp->brothernext;
       }
       while(temp->brotherpre)
       {
           temp=temp->brotherpre;
           temp->brothernext->brotherpre=NULL;
           temp->brothernext->brothernext=NULL;
           destroy(temp->brothernext);
       }
       if(temp->child)
        destroy(temp->child);
       delete p;
    }


//A���������Ƽ���

void Family::buildfamily()
    {
        string name;
        cout<<"������Ҫ������ͥ�˵�����";
        cin>>name;
        Member *p=findmember(name,anc);
        if(p==NULL)
        {
            cout<<"��ǰ����û�������"<<endl;
        }
        if(p->child!=NULL)
        {
            cout<<p->name<<" error"<<endl;
        }
        cout<<"������"<<p->name<<"�Ķ�Ů����";
        cin>>p->num;
        if(p->num==0)
        {
            cout<<"����"<<endl;
            return ;
        }
        cout<<"����������"<<p->name<<"�Ķ�Ů����";
        p->child=buildmember();
        Member *temp=p->child;
        cin>>temp->name;
        temp->dad=p;
        for(int i=0;i<p->num-1;i++)
        {
            Member *b=buildmember();
            cin>>b->name;
            b->dad=p;
            b->brotherpre=temp;
            temp->brothernext=b;
            temp=temp->brothernext;
        }
        printchild(p);
    }

void Family::bulidanc()
    {
       cout<<"���Ƚ���һ������"<<endl<<"�������֣�";
       cin>>anc->name;
       cout<<"������׵������ǣ�"<<anc->name<<endl<<endl;
       cout<<"������Ҫִ�еĲ�����";
    }



//B�����³�Ա

void Family:: addmember()
    {
       cout<<"��˭�����Ӵ��أ�";
       string n;
       cin>>n;
       Member *p=findmember(n,anc);
       if(p==NULL)
       {
           cout<<"û����ˣ�"<<endl;
           return ;
       }
       cout<<"������"<<n<<"�����ӵ��Ӵ������֣�";
       Member *child=buildmember();
       child->dad=p;
       (p->num)++;
       cin>>child->name;
       cout<<n<<"������һ�����ӣ���"<<child->name<<endl;

       Member *temp=p;
       temp=temp->child;
       if(!p->child)
       {
           p->child=child;
           printchild(p);
           return ;
       }
       while(temp->brothernext)
       {
           temp=temp->brothernext;
       }
       temp->brothernext=child;
       printchild(p);

    }



//Cɾ��ĳ����ͥ�����Ӵ�һ��ɾ��

 void Family::divorcemember()
    {
      cout<<"����ɾ��˭ ��";
      string n;
      cin>>n;
      Member *p=findmember(n,anc);
       if(p==NULL)
       {
           cout<<"û����ˣ�"<<endl;
           return ;
       }
       cout<<"��ô��ɾ�������ǣ�"<<p->name<<endl;
       printchild(p);
       if(p->brotherpre&&p->brothernext)
       {
           p->brotherpre->brothernext=p->brothernext;
           p->brothernext->brotherpre=p->brotherpre;
           (p->dad->num)--;
       }
       if(p->brotherpre && !p->brothernext)
       {
           p->brotherpre->brothernext=NULL;
           (p->dad->num)--;
       }
       if(!p->brotherpre && p->brothernext)
       {
           p->dad->child=p->brothernext;
           p->brothernext->brotherpre=NULL;
           (p->dad->num)--;
       }
       if(!p->brotherpre && !p->brothernext)
       {
           p->dad->child==NULL;
           (p->dad->num)--;
       }
       if(p->child)
       {
           destroy(p->child);
       }
       delete(p);

    }


//D���ĳ�Ա������Ϣ

 void Family::changemessage()
    {
      cout<<"�������˭����Ϣ��";
      string n;
      cin>>n;
      Member *p=findmember(n,anc);
      if(p==NULL)
      {
          cout<<"û������ˣ�"<<endl;
          return ;
      }
      else {
        cout<<"���ĺ�����֣�";
      cin>>p->name;
      cout<< n <<" �Ѹ���Ϊ�� "<<p->name;
      }
      return ;
    }


void Family:: printchild(Member *p)
    {
       if(p->num==0)
       {
           cout<<p->name<<" �����û�к����"<<endl;
           return ;
       }
       Member *t=p->child;
       cout<<p->name<<"�ĵ�һ���ǣ�";
       for(int i=0;i<p->num;i++)
       {
           cout<<t->name<<"    ";
           t=t->brothernext;
           if(t==NULL)
           {
               break;
           }
       }
    }




 Member * Family::findmember(string pname,Member *key)
    {
     Member *p=key;
     Member *h=NULL;
     Member *q=p;
     if(p->name==pname)
     {
         return p;
     }
     while (q->brothernext)
     {
         h=findmember(pname,q->brothernext);
         if(h)
        return h;
        q=q->brothernext;
     }
     q=p;
     if(q->child)
        h=findmember(pname,q->child);
     return h;
    }

 Member * Family::buildmember()
    {
      Member *p=NULL;
       p=new Member();
       p->name="zhangsan";
       p->birth=19490101;
       p->gender=1;
       p->num=1;
       p->dad=NULL;
       p->brothernext=NULL;
       p->brotherpre=NULL;
       p->child=NULL;
        return p;
    }

*/
